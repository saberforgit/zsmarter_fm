package com.example.blesearch;

import java.io.FileDescriptor;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import android.R.integer;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.SoundPool;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.util.Log;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BluetoothLeService extends Service {
	public static final boolean isDebug = true;
	//public static final boolean isDebug = false;
	public static final String COMPANY_NAME = "Ceovoe";
	public static boolean isAutoLink = true;
	public static boolean isDiscovered = false;
	public static boolean isconn = false;
	public static boolean isreadRssiOpen = false;
	public static long scantime = 0;
	public static int num = 0;
	public Context context;
	public SharedPreferences settings ;
	public int myRssi;
	
	private final static String TAG = BluetoothLeService.class.getSimpleName();
	public final static int INT_PHOTOGRAPH = 2;
	public static final int SLEEP_TIME	= 500;
	public static final int SCAN_PERIOD = 60000*3;
	public static final int LINK_INERVAL_TIAM = 3000;	//自动连接间隔时间
	public static  int  READ_RSSI_TIME  = 1000;		//读取RSSI的间隔时间
	public static int readnum = 0;
	public static String link_Addr = "1122";
	public int batteryNum = -1;
	public int warningRssi = -85;
	public int monitorRssi = -60;

	//jiang
	private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    public BluetoothGatt mBluetoothGatt;
    public BluetoothGattCharacteristic photoCharacteristic;
    public BluetoothGattCharacteristic device_name;
    public BluetoothGattCharacteristic device_addr;
    public BluetoothGattCharacteristic manufacturer_name;
    public BluetoothGattCharacteristic power_level;
    public BluetoothGattCharacteristic connect_state;
    public MediaPlayer waitiingMP;
    public SoundPool soundPool;
    //存放所有服务
    public ArrayList<BluetoothGattService> bleServices =new ArrayList<BluetoothGattService>();
    
    private AudioManager mAudiomanager;
    private BluetoothDevice LEdevice;								//
    private boolean mScanning = false;
    private boolean isLEenabled = false;
    private static boolean isStatr = false;								//服务停止开关
    private static boolean isDofindService = false;
    private static boolean isFindService = false;
    public Handler mHandler;
    private Handler mVolumeHandler;
    
    private int mConnectionState = STATE_DISCONNECTED;			//连接状态
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;
    private static final int SREVICE_UPDATA = 5;
    
    public final static String STR_PHOTOGRAPH = "Photograph";
    public final String  STR_BROADCAST = "PhotographBroadcast";
    public static long time = 0;
    
    public Hashtable<String,BluetoothDevice>  mDevices = new  Hashtable<String,BluetoothDevice>();
    
    public static Hashtable<String, byte[]> scanDatas = new Hashtable<String, byte[]>();
    
	//监听的UUID
	public static final String LISTEN_SUUID = "0000ffe0-0000-1000-8000-00805f9b34fb";
	public static final String LISTEN_CUUID = "0000ffe1-0000-1000-8000-00805f9b34fb";
	public static final String SLIC_BLE_NOTIFICATION_SERVICE_SIGNAL_UUID = 
			"00001802-0000-1000-8000-00805f9b34fb";
    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";
    private final IBinder mBinder = new LocalBinder();

    
    
    
	//实例化LocalBinder 用于绑定服务
	public class LocalBinder extends Binder {
        BluetoothLeService getService() {
            return BluetoothLeService.this;
        }
    }
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		context = this;
		mHandler = new Handler();
		mVolumeHandler = new Handler();
		initialize();
		settings = getSharedPreferences("setting", 0);
		isreadRssiOpen = settings.getBoolean("openReadRssi", false);
		super.onCreate();
	}
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		Log.e("LE device service", "onDestroy()");
		super.onDestroy();
	}
	@Override
    public IBinder onBind(Intent intent) {
		final Intent intent1 = new Intent(STR_BROADCAST);
        intent1.putExtra(STR_PHOTOGRAPH, SREVICE_UPDATA);
        context.sendBroadcast(intent1);
        return mBinder;
    }
	@Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }
	 public void close() {
	    if (mBluetoothGatt == null) {
	       return;
	       }
	    mBluetoothGatt.disconnect();
	    
	  }
	 //获得已经扫描的设备
	 public Hashtable<String,BluetoothDevice> getBluetoothDevice(){
		 return mDevices;
	 }
	 //初始化LE
	 private void initialize(){
			final BluetoothManager bluetoothManager =
			        (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
			mBluetoothAdapter = bluetoothManager.getAdapter();
			mAudiomanager = (AudioManager) getSystemService(Service.AUDIO_SERVICE);
			isStatr = true;
	 }
	 //扫描LE
	 public boolean scanLeDevice(final boolean enable){
		 if(mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()){
			 return false;
		 }
		 if(mConnectionState == STATE_CONNECTED){
			 //连接上了不扫描
			 return false;
		 }
		 
		 if(enable){
			 mHandler.postDelayed(new Runnable() {
	                @Override
	                public void run() {
	                    mScanning = false;
	                    if(mBluetoothAdapter!=null){
	                    	mBluetoothAdapter.stopLeScan(mLeScanCallback); 
	                    }
	                }
	            }, SCAN_PERIOD);
//			 mDevices.clear();
			 mBluetoothAdapter.startLeScan(mLeScanCallback);
//			 UUID [] serviceUuids = {
//					 UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")};
//			 UUID [] serviceUuids = {
//					 UUID.fromString("00001800-0000-1000-8000-00805f9b34fb"),
//					 UUID.fromString("00001801-0000-1000-8000-00805f9b34fb"),
//					 UUID.fromString("0000180a-0000-1000-8000-00805f9b34fb"),
//					 UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")};
//			 mBluetoothAdapter.startLeScan(serviceUuids, mLeScanCallback);
			 mScanning = true;
		 }
		 else{
			 mBluetoothAdapter.stopLeScan(mLeScanCallback);
			 mScanning = false; 
		 }
		 return true;
	 }
	private BluetoothAdapter.LeScanCallback mLeScanCallback =
		        new BluetoothAdapter.LeScanCallback() {
					private int num = 0;
					@Override
					public void onLeScan(BluetoothDevice device, int rssi,
							byte[] scanRecord) {
						// TODO Auto-generated method stub
						String deviceName = device.getName();
						String deviceAddr = device.getAddress();
						
						if(null == deviceName || "".equals(deviceName)){
							return;
						}

						
						ParcelUuid[]  uuids = device.getUuids();
						if(uuids!=null){
							for(ParcelUuid mParcelUuid:uuids){
								Log.e("", "--!!-- "+mParcelUuid.getUuid().toString());
							}
						}
						
						String data = "";
						if(scanRecord!=null){
							for (int i = 0; i < scanRecord.length; i++) {
								byte sRecord = scanRecord[i];
								
								data = data+" "+Integer.toHexString((0xff&scanRecord[i]));
							}
						}
//						Log.e("", "data = "+data);
						
						
						
//						Log.e("", "---"+deviceName+"---");
						if(device.getName().contains("Magic-")){
							mDevices.put(device.getAddress(), device);
							scanDatas.put(device.getAddress(), scanRecord);
							final Intent intent = new Intent(STR_BROADCAST);
							intent.putExtra(STR_PHOTOGRAPH, SREVICE_UPDATA);
							context.sendBroadcast(intent);
						}

					}
		};
		
	//连接LE
	@SuppressLint("NewApi")
	public BluetoothGatt connectGatt(String address){
			LEdevice = mBluetoothAdapter.getRemoteDevice(address);
			mBluetoothGatt = LEdevice.connectGatt(context, true, mGattCallback);
			return mBluetoothGatt;
		}
	//BluetoothGattCallback 	LEGATT 回调
	private final BluetoothGattCallback mGattCallback =
	            new BluetoothGattCallback() {
		private  long fasttime = 0;
		private  long fastdata = 0;
		private long linktime = 0;
			//连接状态
			@Override
			public void onConnectionStateChange(BluetoothGatt gatt, int status,
	                int newState) {
				Log.e("##########", "newState = "+newState);
				mConnectionState = newState;
				if (newState == BluetoothProfile.STATE_CONNECTED) {
	                mConnectionState = STATE_CONNECTED;
	                isreadRssiOpen = settings.getBoolean("openReadRssi", false);
	                Date date = new Date();
					linktime = date.getTime();
	                if(isDebug){
		                isconn = true;
		                if (null != mBluetoothGatt ) {
		                	mConnectionState = STATE_CONNECTING;
		                	mVolumeHandler.postDelayed(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									mBluetoothGatt.discoverServices();	
								}
							}, 50);
		                	
		                	final Intent intent = new Intent(STR_BROADCAST);
					        intent.putExtra(STR_PHOTOGRAPH, 6);
					        context.sendBroadcast(intent);
						}
	                }
	            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
	            	Log.e("##########", "断开");
	            	mConnectionState = STATE_DISCONNECTED;
	            	isDiscovered = false;
	            	isconn = false;
	                LEdevice = null;
	                fasttime = 0;
	                batteryNum = -1;
	                final Intent intent = new Intent(STR_BROADCAST);
			        intent.putExtra(STR_PHOTOGRAPH, 7);
			        context.sendBroadcast(intent);
			        Date now = new Date();
			        if(isreadRssiOpen&&now.getTime()-linktime>4500){
			        }
			        try {
				        mBluetoothGatt.close();
					    mBluetoothGatt = null;
					    } catch (Exception e) {
						// TODO: handle exception
					    	}
			        }
				uiNotify();
				
			}
			//获取数据
			@Override
			public void onServicesDiscovered(BluetoothGatt gatt, int status) {
				Date now = new Date();
				if (null != gatt){
					 mBluetoothGatt = gatt;
				}
	            if (status == BluetoothGatt.GATT_SUCCESS) {
	            	isFindService = true;
			        isStatr = true; 
			        //setNotify();
			        isDiscovered = true;
			        mConnectionState = STATE_CONNECTED; 	  
			        Log.e("---", "获取服务OK！");
			        final Intent intent = new Intent(STR_BROADCAST);
			        intent.putExtra(STR_PHOTOGRAPH, 8);
			        context.sendBroadcast(intent);
			        bleServices =  (ArrayList<BluetoothGattService>) gatt.getServices();
			        if(bleServices==null||bleServices.isEmpty()){
			        	return;
			        }
			        for (int i = 0; i < bleServices.size(); i++) {
			        	BluetoothGattService mBluetoothGattService = bleServices.get(i);
					}

	            }
	            else{
	            	Log.e(TAG, "onServicesDiscovered false! status = "+status );
	            	final Intent intent = new Intent(STR_BROADCAST);
			        intent.putExtra(STR_PHOTOGRAPH, 11);
			        context.sendBroadcast(intent);
			        isStatr = false;
	            }
	            uiNotify();
	        }
			//写入Descriptor
			@Override
			public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor,
	                 int status) {
				 
				 if (status == BluetoothGatt.GATT_SUCCESS) {  
		            	final Intent intent = new Intent(STR_BROADCAST);
				        intent.putExtra(STR_PHOTOGRAPH, 6);
				        context.sendBroadcast(intent);
			        }           
			        else{ 
			        	Log.e(TAG, "Callback: Error writing GATT Descriptor: " +status +" uuid = "+descriptor.getUuid().toString());		  
			         	final Intent intent = new Intent(STR_BROADCAST);
				        intent.putExtra(STR_PHOTOGRAPH, 10);
				        context.sendBroadcast(intent);
			        }
				 super.onDescriptorWrite(gatt, descriptor, status);
			 }
			//写入数据
			@Override
			public void onCharacteristicWrite(BluetoothGatt gatt,
	                 BluetoothGattCharacteristic characteristic, int status) { 
				Log.e("写入数据", ""+characteristic.getUuid().toString());
				byte[] data = characteristic.getValue();
				for (int i = 0; i < data.length; i++) {
					Log.e("", "0x"+Integer.toHexString(data[i]&0xff));
				}
			}
			private int counter = 0;
			private int cache = monitorRssi;
			//获取信号强度
			public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
				Log.e(TAG, "rssi = "+rssi);
				//Log.e(TAG, "status = "+status);
				myRssi = rssi;
				final Intent intent = new Intent(STR_BROADCAST);
		        intent.putExtra(STR_PHOTOGRAPH, 11);
		        context.sendBroadcast(intent);
				num--;
				if(rssi>100){
					return;
				}
				//jiang
				if(rssi<warningRssi){
					Log.e(TAG, "报警  rssi = "+rssi);
					cache = monitorRssi;
					counter = 0;
					//READ_RSSI_TIME = 500;
					openRound(true);
				}
				else if (rssi>-45){
				}
				
			};
			public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor,
	                 int status) { 
			}
			
			//notify
			 @Override
			 public void onCharacteristicChanged(BluetoothGatt gatt,
	                 BluetoothGattCharacteristic characteristic) {
				 
				 Log.e("CharacteristicChanged", ""+characteristic.getUuid().toString());
				 
			     if(characteristic!=null){
			    	 final byte[] data = characteristic.getValue();
			    	 
			    	 String nc = "";
			    	 if(data!=null && data.length>0){
			    		for (int j = 0; j < data.length; j++) {
			    			 nc = nc +" "+Integer.toHexString(data[j]);
						}
			    		Log.e("CharacteristicChanged", "Changed = "+nc);  
			    	 }
			    	 
//			    	 Log.e("CharacteristicChanged", "notify!!");
			    	 int data1 = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 0);
				      final Intent intent3 = new Intent("getdata");
					    intent3.putExtra("int"+characteristic.getUuid().toString(), data1);
					    intent3.putExtra("byte"+characteristic.getUuid().toString(), data);
					    context.sendBroadcast(intent3); 
			    	 }
			 }
			 //BluetoothGatt 读数据
			 public void onCharacteristicRead(BluetoothGatt gatt,
		                BluetoothGattCharacteristic characteristic,int status) {
				 mBluetoothGatt = gatt;
				 readnum--;
				 if (status == BluetoothGatt.GATT_SUCCESS) {
		                //broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
		            	//System.out.println("回调读characteristic的结果  status=GATT_SUCCESS  "+status);
		         }
				 if(characteristic!=null){
			    	 final byte[] data = characteristic.getValue();
			    	 Log.e("CharacteristicChanged", "read!!");
			    	 int data1 = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 0);
				      final Intent intent3 = new Intent("getdata");
					    intent3.putExtra("int"+characteristic.getUuid().toString(), data1);
					    intent3.putExtra("byte"+characteristic.getUuid().toString(), data);
					    context.sendBroadcast(intent3); 
			    }
			 }
		};
		
	public void stopLEService(){
		Log.e(TAG, "stopLEService()");
		if(mBluetoothGatt == null){
			return;
		}
		mBluetoothGatt.disconnect();
		isStatr = false;
	}
	// 读数据
	public void readData(String serviceUUID,String characteristicUUID){
		UUID suuid = UUID.fromString(serviceUUID);
		UUID cuuid = UUID.fromString(characteristicUUID);
		if (mBluetoothGatt == null){
			return;
		}
		BluetoothGattService mService = mBluetoothGatt.getService(suuid);
		BluetoothGattCharacteristic cli = mService.getCharacteristic(cuuid);
		mBluetoothGatt.readCharacteristic(cli);
	}
	//  设置Notify
	public boolean setNotify(String serviceUUID,String characteristicUUID){
		UUID suuid = UUID.fromString(serviceUUID);
		UUID cuuid = UUID.fromString(characteristicUUID);
		if (mBluetoothGatt == null){
			return false;
		}
		BluetoothGattService mService = mBluetoothGatt.getService(suuid);
		if(mService == null){
			Log.e(TAG, "mService == null");
			return false;
		}
		photoCharacteristic = mService.getCharacteristic(cuuid);
		boolean flay = mBluetoothGatt.setCharacteristicNotification(photoCharacteristic, true);
		BluetoothGattDescriptor descriptor = photoCharacteristic.getDescriptor(
		        UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
		if(descriptor != null){
			descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
			mBluetoothGatt.writeDescriptor(descriptor);
			return true;
		}
		//descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
		
		return false;
	}
	private void setNotify(){
		UUID suuid = UUID.fromString(LISTEN_SUUID);
		UUID cuuid = UUID.fromString(LISTEN_CUUID);
		if (mBluetoothGatt == null){
			return;
		}
		BluetoothGattService mService = mBluetoothGatt.getService(suuid);
		if(mService == null){
			Log.e(TAG, "mService == null");
			return;
		}
		photoCharacteristic = mService.getCharacteristic(cuuid);
		boolean flay = mBluetoothGatt.setCharacteristicNotification(photoCharacteristic, true);
		System.out.println(" setCharacteristicNotification = "+flay);
		BluetoothGattDescriptor descriptor = photoCharacteristic.getDescriptor(
		        UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
		descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
		mBluetoothGatt.writeDescriptor(descriptor);
	}
	//写入数据
	public void writeCharacteristic(String serviceUUID,String characteristicUUID,byte [] flay){
		UUID suuid = UUID.fromString(serviceUUID);
		UUID cuuid = UUID.fromString(characteristicUUID);
		if (mBluetoothGatt == null){
			return;
		}
		BluetoothGattService mService = mBluetoothGatt.getService(suuid);
		BluetoothGattCharacteristic cli = mService.getCharacteristic(cuuid);
		cli.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
		cli.setValue(flay);
		mBluetoothGatt.writeCharacteristic(cli);
	}
	//写入数据
	public void writeCharacteristic(String serviceUUID,String characteristicUUID,byte [] flay,int num){
		UUID suuid = UUID.fromString(serviceUUID);
		UUID cuuid = UUID.fromString(characteristicUUID);
		if (mBluetoothGatt == null){
			return;
		}
		BluetoothGattService mService = mBluetoothGatt.getService(suuid);
		BluetoothGattCharacteristic cli = mService.getCharacteristic(cuuid);
		cli.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
		cli.setValue(flay);
		mBluetoothGatt.writeCharacteristic(cli);
	}
	
	
	
	public void openRound(boolean flay){
		BluetoothGattService myService = null;
		if (null != mBluetoothGatt) {
			UUID ser_uuid = UUID.fromString(DeviceUUID.SLIC_BLE_WRITE_SERVICE_SOUND_ALERT_HIGH_UUID);				
			UUID cil_uuid = UUID.fromString(DeviceUUID.SLIC_BLE_WRITE_CHARACTERISTICS_SOUND_ALERT_UUID);	//写入蜂鸣器的UUID
			myService = mBluetoothGatt.getService(ser_uuid);
			if (null != myService){
				BluetoothGattCharacteristic cli = myService.getCharacteristic(cil_uuid);
				if (cli != null){
					if (flay){
						cli.setValue(new byte []{2});
					}
					else{
						cli.setValue(new byte []{0});
					}
					
					Boolean bool = mBluetoothGatt.writeCharacteristic(cli);
					if (!bool){
						//System.out.println("writeCharacteristic(cli) 失败！");
					}
				}
				else{
					//System.out.println("cliCharacteristic == null");
					return;
				}
			}
		}
	}
	public int getConnectionState(){
		return mConnectionState;
	}
	public void setIsAutoLink(boolean isAutoLink){
		this.isAutoLink = isAutoLink;
	}
	
	public void cycleScanLE(){
//		 mDevices.clear();
		 mBluetoothAdapter.startLeScan(mLeScanCallback);
		 mScanning = true;
	}
	public BluetoothDevice getLEdevice(){
		return LEdevice;
	}
	public void uiNotify(){
//        final Intent intent = new Intent(STR_BROADCAST);
//        intent.putExtra(STR_PHOTOGRAPH, 5);
//        context.sendBroadcast(intent);
	}
	public int getDeviceBattry(){
		return batteryNum;
	}
	public boolean getDeviceRssi(){
		boolean flay = false;
		try {
			flay = mBluetoothGatt.readRemoteRssi();
			
		} catch (Exception e) {
			// TODO: handle exception
			Log.e("@@##", "mBluetoothGatt.readRemoteRssi  出错！");
		}
		return flay;
	}
	
}
