package com.example.blesearch;

import java.util.ArrayList;


import com.example.blesearch.ServicesActivity.ViewHolder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class CharacteristicActivity extends Activity{
    private ServiceConnection sc;
    private BluetoothLeService mBluetoothLeService; //蓝牙服务
	public static BluetoothAdapter mBluetoothAdapter;
	public static Resources mResources;
	public static Context context;
	public int position = -1;
	public ListView characteristicsList;
	public LeDeviceListAdapter mLeDeviceListAdapter;
	public BluetoothGattService mBluetoothGattService;
	
	public ArrayList<BluetoothGattCharacteristic> myCharacteristics = new ArrayList<BluetoothGattCharacteristic>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.characteristic_activity);
		mResources = getResources();
		context = this; 
		init();
		characteristicsList = (ListView) findViewById(R.id.characteristics_list);
		mLeDeviceListAdapter = new LeDeviceListAdapter();
		characteristicsList.setAdapter(mLeDeviceListAdapter);
		characteristicsList.setOnItemClickListener(myOnItemClickListener);
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		Intent inte = getIntent();
		position = inte.getIntExtra("position", -1);
		if(position == -1){
			finish();
		}
		//Log.e("", "position = "+position);
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		
//		this.unbindService(sc);
	}
	private void init(){
		sc = new ServiceConnection(){
			@Override
			public void onServiceConnected(ComponentName name, IBinder service) {
				// TODO Auto-generated method stub
				mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
				//myCharacteristics
				ArrayList<BluetoothGattService> bleServices = mBluetoothLeService.bleServices;
		        if(bleServices==null||bleServices.isEmpty()){
		        	Toast.makeText(context, "服务获取失败！", Toast.LENGTH_SHORT).show();
		        	return;
		        }
				mBluetoothGattService = bleServices.get(position);
				myCharacteristics = (ArrayList<BluetoothGattCharacteristic>) mBluetoothGattService.getCharacteristics();
				mLeDeviceListAdapter.setData(myCharacteristics);
				mLeDeviceListAdapter.notifyDataSetChanged();
				
			}
			@Override
			public void onServiceDisconnected(ComponentName name) {
				// TODO Auto-generated method stub
				
			}
		};
		Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);
	}
    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothGattCharacteristic> mCharacteristics;
        private LayoutInflater mInflator;

        public LeDeviceListAdapter() {
            super();
            mCharacteristics = new ArrayList<BluetoothGattCharacteristic>();
            mInflator = CharacteristicActivity.this.getLayoutInflater();
        }

        public void setData(ArrayList<BluetoothGattCharacteristic> mServices){
        	this.mCharacteristics = mServices;
        }

        public BluetoothGattCharacteristic getService(int position) {
            return mCharacteristics.get(position);
        }

        public void clear() {
        	mCharacteristics.clear();
        }

        @Override
        public int getCount() {
            return mCharacteristics.size();
        }

        @Override
        public Object getItem(int i) {
            return mCharacteristics.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                view = mInflator.inflate(R.layout.service_listitem_device, null);
                viewHolder = new ViewHolder();
                viewHolder.serviceUUID = (TextView) view.findViewById(R.id.Service_uuid);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }
            BluetoothGattCharacteristic service = mCharacteristics.get(i);
            String uuid = service.getUuid().toString();
//            if(uuid!=null&&uuid.length()>=24){
//            	uuid = uuid.substring(0, 24);
//            }
            final String serviceUUID = "   UUID :" +service.getUuid().toString();
			Log.d("uuid",serviceUUID);
            if (serviceUUID != null && serviceUUID.length() > 0)
                viewHolder.serviceUUID.setText(serviceUUID);
            else
                viewHolder.serviceUUID.setText(serviceUUID);
            return view;
        }
    }
    static class ViewHolder {
        TextView serviceUUID;
    }
    private OnItemClickListener myOnItemClickListener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub

			BluetoothGattCharacteristic myBluetoothGattCharacteristic 
				= mLeDeviceListAdapter.mCharacteristics.get(arg2);
			Log.e("", "Characteristic uuid = "+myBluetoothGattCharacteristic.getUuid().toString());
			//Log.e("", "Characteristic uuid = "+arg2);
			Intent intent = new Intent(CharacteristicActivity.this,ReadAndwriteActivity.class);
			intent.putExtra("position", arg2);
			intent.putExtra("Service", ""+mBluetoothGattService.getUuid().toString());
			intent.putExtra("Characteristic", ""+myBluetoothGattCharacteristic.getUuid().toString());
			context.startActivity(intent);
		}
	};
}
