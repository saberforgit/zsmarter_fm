package com.example.blesearch;

import java.util.UUID;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.util.Log;

public class DeviceUUID {
	public final static String SLIC_BLE_READ_SERVICE_INFO_UUID =
			"00001800-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_INFO_DEVICE_NAME_UUID = 
			"00002a00-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_INFO_APPEARANCE_UUID = 
			"00002a01-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_INFO_ADDRESS_UUID = 
			"00002a03-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_SERVICE_DEVICE_INFO_UUID =
			"0000180a-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_DEVICE_INFO_MANUFACTURER_NAME_UUID = 
			"00002a29-0000-1000-8000-00805f9b34fb";
	public final static int SLIC_BLE_MANUFACTURER_DATA_LEN = 4;
	public final static String SLIC_BLE_WRITE_SERVICE_SOUND_ALERT_HIGH_UUID =
			"00001802-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_WRITE_CHARACTERISTICS_SOUND_ALERT_UUID = 
			"00002a06-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_NOTIFICATION_SERVICE_SIGNAL_UUID =
			"00001803-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_NOTIFICATION_CHARACTERISTICS_SIGNAL_UUID = 
			"00002a06-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_SERVICE_TX_POWER_LEVEL_UUID =
			"00001804-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_TX_POWER_LEVEL_UUID = 
			"00002a07-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_SERVICE_BATTERY_UUID =
			"0000180f-0000-1000-8000-00805f9b34fb";
	public final static String SLIC_BLE_READ_CHARACTERISTICS_BATTERY_UUID = 
			"00002a19-0000-1000-8000-00805f9b34fb";
	public final static String CONSMART_BLE_NOTIFICATION_SERVICE_CAMERA_UUID =
			"0000ffe0-0000-1000-8000-00805f9b34fb";
	public final static String CONSMART_BLE_NOTIFICATION_CHARACTERISTICS_CAMERA_UUID = 
			"0000ffe1-0000-1000-8000-00805f9b34fb";
	public final static String SWITCH_CAMERA_FIND_SERVICE = "0000ffd0-0000-1000-8000-00805f9b34fb";
	public final static String SWITCH_CAMERA_FIND_CHARA = "0000ffd1-0000-1000-8000-00805f9b34fb";
	public final static UUID SERVICE_INFO_UUID = UUID.fromString(SLIC_BLE_READ_SERVICE_INFO_UUID);
	public final static UUID DEVICE_NAME_UUID  = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_INFO_DEVICE_NAME_UUID);
	public final static UUID APPEARANCE_UUID  = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_INFO_APPEARANCE_UUID);
	public final static UUID ADDRESS_UUID = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_INFO_ADDRESS_UUID);
	public final static UUID SERVICE_DEVICE_INFO_UUID = UUID.fromString(SLIC_BLE_READ_SERVICE_DEVICE_INFO_UUID);
	public final static UUID MANUFACTURER_NAME_UUID = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_DEVICE_INFO_MANUFACTURER_NAME_UUID);
	public final static UUID SERVICE_SOUND_ALERT_HIGH_UUID = UUID.fromString(SLIC_BLE_WRITE_SERVICE_SOUND_ALERT_HIGH_UUID);
	public final static UUID CHARACTERISTICS_SOUND_ALERT_UUID = UUID.fromString(SLIC_BLE_WRITE_CHARACTERISTICS_SOUND_ALERT_UUID);
	public final static UUID SERVICE_SIGNAL_UUID = UUID.fromString(SLIC_BLE_NOTIFICATION_SERVICE_SIGNAL_UUID);
	public final static UUID CHARACTERISTICS_SIGNAL_UUID = UUID.fromString(SLIC_BLE_NOTIFICATION_CHARACTERISTICS_SIGNAL_UUID);
	public final static UUID POWER_LEVEL_UUID = UUID.fromString(SLIC_BLE_READ_SERVICE_TX_POWER_LEVEL_UUID);
	public final static UUID CHARACTERISTICS_TX_POWER_LEVEL_UUID = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_TX_POWER_LEVEL_UUID);
	public final static UUID SERVICE_BATTERY_UUID = UUID.fromString(SLIC_BLE_READ_SERVICE_BATTERY_UUID);
	public final static UUID CHARACTERISTICS_BATTERY_UUID = UUID.fromString(SLIC_BLE_READ_CHARACTERISTICS_BATTERY_UUID);
	//
	public final static UUID SERVICE_CAMERA_UUID = UUID.fromString(CONSMART_BLE_NOTIFICATION_SERVICE_CAMERA_UUID);
	public final static UUID CHARACTERISTICS_CAMERA_UUID = UUID.fromString(CONSMART_BLE_NOTIFICATION_CHARACTERISTICS_CAMERA_UUID);
//	public BluetoothGattService deviceService;
//	public BluetoothGattCharacteristic deviceCharacter;
//	public BluetoothGattService manufacturerService;
//	public BluetoothGattCharacteristic manufacturerCharacter;
//	public BluetoothGattService soundService;
//	public BluetoothGattCharacteristic soundCharacter;
//	public BluetoothGattService signalService;
//	public BluetoothGattCharacteristic signalCharacter;
//	
//	public BluetoothGattService powerService;
//	public BluetoothGattCharacteristic powerCharacter;
//	public BluetoothGattService batteryService;
//	public BluetoothGattCharacteristic batteryCharacter;
//	public BluetoothGattService cameraService;
//	public BluetoothGattCharacteristic cameraCharacter;
	public static boolean isCamera = false;
	public static boolean isLock = false;
	public static String get16uuid(String uuid){
		String muuid = "";
        if(uuid!=null&&uuid.length()>=9){
        	muuid = uuid.substring(4, 8);
        }
		return muuid;
	}
	public static byte[] numtobyte(byte[]flay){
		int nu = 0;
		if(flay == null ||flay.length ==0){
			return null;
		}
		
//		if(flay.length==1){
//			int k = getNum(flay[0]);
//			byte [] a  = {(byte) k};;
//			return a;
//		}
		
		byte[] data;
		
		byte[] flay1 ;
		
		if(flay.length%2==0){
			data= new byte[flay.length/2] ;
			flay1 = flay;
		}
		else{
			data= new byte[(flay.length/2)+1] ;
			flay1 = new byte[flay.length+1];
			flay1[0]  = 0;
			for (int i = 0; i < flay.length; i++) {
				flay1[i+1] = flay[i];
			}
		}
		
		for (int i = 0; i < flay1.length; i++) {
			if(i%2==0){
				nu = getNum(flay1[i]);
			}
			else{
				nu = nu*16+ getNum(flay1[i]);
				if(i/2<data.length){
					data[i/2] = (byte) nu;
				}
			}
		}
		
		
		return data;
	}
	
	public static byte getNum(byte num){
		byte n = 0;
		switch (num) {
		case 'a':
			n = 10;
			break;
		case 'A':
			n = 10;
			break;
		case 'b':
			n = 11;
			break;
		case 'B':
			n = 11;
			break;
		case 'c':
			n = 12;
			break;
		case 'C':
			n = 12;
			break;
		case 'd':
			n = 13;
			break;
		case 'D':
			n = 13;
			break;
		case 'e':
			n = 14;
			break;
		case 'E':
			n = 14;
			break;
		case 'f':
			n = 15;
			break;
		case 'F':
			n = 15;
			break;
		case '0':
			n = 0;
			break;
		case '1':
			n = 1;
			break;
		case '2':
			n = 2;
			break;
		case '3':
			n = 3;
			break;
		case '4':
			n = 4;
			break;
		case '5':
			n = 5;
			break;
		case '6':
			n = 6;
			break;
		case '7':
			n = 7;
			break;
		case '8':
			n = 8;
			break;
		case '9':
			n = 9;
			break;

		default:
			break;
		}
		return n;
	}

}
