package com.example.blesearch;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Application;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;
import java.util.UUID;

/**
 * Created by wangxf on 2017/3/31.
 */

public class LEDAppcliction extends Application {

    private ServiceConnection sc;
    private BluetoothLeService mBluetoothLeService; //蓝牙服务
    public static BluetoothAdapter mBluetoothAdapter;
    private ProgressDialog progressDialog;

    ////////////////////////////////
    public final static String STR_PHOTOGRAPH = "Photograph";
    public final String  STR_BROADCAST = "PhotographBroadcast";
    private int mConnectionState = STATE_DISCONNECTED;			//连接状态
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;
    private static final int SREVICE_UPDATA = 5;
    public String cuuid = "";
    public String suuid = "";
    private Handler mHandler = new Handler(new android.os.Handler.Callback() {

        @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
        public boolean handleMessage(Message msg) {
            // TODO Auto-generated method stub
            switch (msg.what) {
                case 1:
                    break;
                case 2:
                    //连接成功
                    showProgressDialog("获取服务...");
                    break;
                case 3:
                    //获取服务成功
                    closeProgressDialog();
//				Intent intent = new Intent();
//		        intent.setClass(SearchActivity.this, ServicesActivity.class);
//		        /* 启动一个新的Activity */
//		        SearchActivity.this.startActivityForResult(intent, 1);
                    for (int i = 0; i < mBluetoothLeService.bleServices.size(); i++) {
                        BluetoothGattService mBluetoothGattService = mBluetoothLeService.bleServices.get(i);
                        if(mBluetoothGattService.getUuid().toString().equals(getResources().getString(R.string.bluetooth_service_UUID))){
                            Log.e("service-select", ""+mBluetoothGattService.getUuid());
                            List<BluetoothGattCharacteristic> bleServices = mBluetoothGattService.getCharacteristics();
                            for (BluetoothGattCharacteristic bleService : bleServices) {
                                if(bleService.getUuid().toString().equals(getResources().getString(R.string.bluetooth_second_service_UUID))){
                                    Log.e("service-select", ""+bleService.getUuid().toString());
//								Intent intent = new Intent(SearchActivity.this,ReadAndwriteActivity.class);
//								intent.putExtra("Service", ""+mBluetoothGattService.getUuid().toString());
//								intent.putExtra("Characteristic", ""+bleService.getUuid().toString());
//								SearchActivity.this.startActivity(intent);
                                    suuid = mBluetoothGattService.getUuid().toString();
                                    cuuid = bleService.getUuid().toString();
                                    Intent gattServiceIntent = new Intent(LEDAppcliction.this, BluetoothLeService.class);
                                    bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);
                                }
                            }
//						Intent intent = new Intent(SearchActivity.this,CharacteristicActivity.class);
//						intent.putExtra("position", i);
//						context.startActivity(intent);
                        }
                    }
                    break;
                default:
                    break;
            }
            return false;
        }
    });
    //接收广播
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            //处理蓝牙连接
            int status = intent.getIntExtra(STR_PHOTOGRAPH, 1000);
            if(1000 != status){
                switch (status) {
                    case 2:
                        break;
                    case SREVICE_UPDATA :
                        if (null != mBluetoothLeService){
                        }
                        mHandler.sendEmptyMessage(1);
                        break;
                    case 6 :
                        Toast.makeText(context, "连接成功！", Toast.LENGTH_LONG).show();
                        mHandler.sendEmptyMessage(2);
                        break;
                    case 7:
                        //断开连接
                        closeProgressDialog();
                        Toast.makeText(context, "连接断开", Toast.LENGTH_SHORT).show();
                        break;
                    case 8:
                        //获取服务成功
                        mHandler.sendEmptyMessage(3);
                        break;
                    case 9:
                        Toast.makeText(context, "Callback: Wrote GATT Descriptor successfully", Toast.LENGTH_LONG).show();
                        break;
                    case 10:
                        Toast.makeText(context, "Callback: Error writing GATT Descriptor", Toast.LENGTH_LONG).show();
                        break;
                    case 11:
                        //获取服务异常！
                        Toast.makeText(context, "获取服务异常！", Toast.LENGTH_LONG).show();
                        break;
                }
            }
        }
    };

    public void closeProgressDialog(){
        if(null==progressDialog){
            return;
        }
        progressDialog.dismiss();
    }
    public void showProgressDialog(String msg){
        if(null==progressDialog){
            return;
        }
        progressDialog =ProgressDialog.show(this, msg, "请等待...", true, false);
    }
    @Override
    public void onCreate() {
        super.onCreate();
        this.
        init();
    }
    //初始化
    @SuppressLint("NewApi") private void init(){

        final BluetoothManager bluetoothManager =(BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        boolean bleIsOpen = mBluetoothAdapter.isEnabled();
        if (mBluetoothAdapter == null || !bleIsOpen) {
//            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//            LEDAppcliction.context.get.startActivityForResult(enableBtIntent, 1);
            Toast.makeText(LEDAppcliction.this, "请打开蓝牙", Toast.LENGTH_LONG).show();
        }

        sc = new ServiceConnection(){
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                // TODO Auto-generated method stub
                mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
                getPermissions();
            }
            @Override
            public void onServiceDisconnected(ComponentName name) {
                // TODO Auto-generated method stub

            }
        };
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(STR_BROADCAST);   //为BroadcastReceiver指定action，使之用于接收同action的广播
        registerReceiver(mGattUpdateReceiver,intentFilter);
    }


    @SuppressLint("NewApi")
    private void getPermissions() {
        if (mBluetoothLeService != null && mBluetoothLeService.mBluetoothGatt != null) {
            Log.e("", "---->getPermissions");
            UUID sid = UUID.fromString(suuid);
            UUID cid = UUID.fromString(cuuid);

            BluetoothGattService mService = mBluetoothLeService.mBluetoothGatt.getService(sid);
            BluetoothGattCharacteristic cli = mService.getCharacteristic(cid);
            int Permissions = cli.getPermissions();
            int Properties = cli.getProperties();
            Log.e("", "Permissions " + Permissions);
            Log.e("", "Properties " + Properties);
            Log.e("", "getWriteType " + cli.getWriteType());

//			int read = Properties&(BluetoothGattCharacteristic.);
            if ((BluetoothGattCharacteristic.PROPERTY_READ)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_READ))) {
                //Characteristic property: Characteristic is readable.
                Log.e("", "读取");
            }

            if ((BluetoothGattCharacteristic.PROPERTY_WRITE)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  写
            }

            if ((BluetoothGattCharacteristic.PROPERTY_NOTIFY)
                    == (Properties & (BluetoothGattCharacteristic.PERMISSION_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  读
            }


        }

    }
}
