package com.example.blesearch;

import java.util.ArrayList;
import java.util.Date;


import java.util.UUID;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Vibrator;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.qh.aes.AES;

public class ReadAndwriteActivity extends Activity {
    private ServiceConnection sc;
    private BluetoothLeService mBluetoothLeService; //蓝牙服务
    public static BluetoothAdapter mBluetoothAdapter;
    public Context context;
    public static Resources mResources;
    public int position = -1;
    public String cuuid = "";
    public String suuid = "";
    private TextView txCharacteristic;
    private TextView txSrevice;
    private Button btn_read;
    private Button btn_write;
    private Button btn_notify;
    private EditText et_readdata; //editText1
    private EditText et_readdata_hx; //editText3
    private EditText et_writedata; //editText2
    private CheckBox cb_refresh;
    public boolean isRrefresh = false;
    public int data = -1;
    byte[] data1;

    private boolean isRead = false;
    private boolean isWrite = false;
    private boolean isNotify = false;

    public Handler mHandler = new Handler(new android.os.Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            // TODO Auto-generated method stub
            switch (msg.what) {
                case 0:
                    upData();
                    break;
            }

            return false;
        }
    });

    //接收广播
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        private long fastTime = 0;

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            //处理蓝牙连接

            data = intent.getIntExtra("int" + cuuid, -1);
            data1 = intent.getByteArrayExtra("byte" + cuuid);
            try {
                Log.e("数据 int ", "" + data);
                Log.e("数据 byte ", "" + data1[0]);
            } catch (Exception e) {
                // TODO: handle exception
                Log.e("", "出错了！");
            }
            mHandler.sendEmptyMessage(0);


        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.readandwrite_activity);
        context = this;
        mResources = getResources();
        txCharacteristic = (TextView) findViewById(R.id.tx_suuid);
        txSrevice = (TextView) findViewById(R.id.tx_cuuid);
        btn_read = (Button) findViewById(R.id.btn_cread);
//		btn_read.setClickable(false);
//		btn_read.setEnabled(false);
        btn_notify = (Button) findViewById(R.id.btn_notify);
//		btn_notify.setClickable(false);
//		btn_notify.setEnabled(false);
        btn_write = (Button) findViewById(R.id.button1);
//		btn_write.setClickable(false);
//		btn_write.setEnabled(false);
        btn_read.setOnClickListener(myOnClickListener);
        btn_notify.setOnClickListener(myOnClickListener);
        btn_write.setOnClickListener(myOnClickListener);
        et_readdata = (EditText) findViewById(R.id.editText1);
        et_writedata = (EditText) findViewById(R.id.editText2);
        et_readdata_hx = (EditText) findViewById(R.id.editText3);
        cb_refresh = (CheckBox) findViewById(R.id.checkBox1);
        cb_refresh.setOnCheckedChangeListener(myOnCheckedChangeListener);
        init();

    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        Intent inte = getIntent();
        position = inte.getIntExtra("position", -1);
        cuuid = inte.getStringExtra("Characteristic");
        suuid = inte.getStringExtra("Service");
        txSrevice.setText("Service uuid: " + DeviceUUID.get16uuid(cuuid));
        txCharacteristic.setText("Characteristic uuid: " + DeviceUUID.get16uuid(suuid));

        super.onResume();
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
//		this.getApplicationContext().unbindService(sc);
    }

    private void init() {
        sc = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                // TODO Auto-generated method stub
                mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
                //myCharacteristics
                getPermissions();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                // TODO Auto-generated method stub

            }
        };
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("getdata");   //为BroadcastReceiver指定action，使之用于接收同action的广播
        registerReceiver(mGattUpdateReceiver, intentFilter);
    }

    boolean isRed = true;
    boolean isStart = false;
    private OnClickListener myOnClickListener = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            switch (v.getId()) {
                case R.id.button1:
                    //写数据
                    Log.e("", "写数据");
                    if (mBluetoothLeService == null) {
                        Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                        break;
                    }
//                    Editable mEditable = et_writedata.getText();
//                    byte[] flay = mEditable.toString().getBytes();
//				if(flay==null||flay.length<0){
//					break;
//				}
//                    flay = DeviceUUID.numtobyte(flay);
//				if(flay==null){
//
//				}
//				for (int i = 0; i < flay.length; i++) {
//					Log.e("--0--", ""+flay[i]);
//				}
                    byte[] jm;
//                    if(!isStart){
//                        jm = new byte[]{(byte) 0xFB, (byte) 0xf0,(byte) 0xFA    };
//                        isStart = true;
//                    }else
//                    {
//                        isStart = false;
//                        jm = new byte[]{(byte) 0xFB, (byte) 0x0f,(byte) 0xFA};
//                    }

//                    if (isRed) {
//                        jm = new byte[]{(byte) 0x28, (byte) 0x37,
//                                (byte) 0x28, (byte) 67, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//                                (byte) 0xF0, (byte) 0x29};
//                        isRed = false;
//                    } else {
//                        isRed = true;
//                        jm = new byte[]{(byte) 0x28, (byte) 0xFF,
//                                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//                                (byte) 0xF0, (byte) 0x29};
//                    }
                    jm = new byte[]{(byte) 0xBB, (byte) 0xF0,(byte) 0xCC};
//				jm  = AES.encrypt(AES.content,AES.password);
                    mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);

//				mBluetoothLeService.writeCharacteristic(suuid, cuuid, flay);


                    doVibrator(true);
                    break;
                case R.id.btn_notify:
                    //设置notify
                    Log.e("", "设置notify");
                    if (mBluetoothLeService == null) {
                        Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    if (!mBluetoothLeService.setNotify(suuid, cuuid)) {
                        Toast.makeText(context, "操作失败 setNotify false!", Toast.LENGTH_SHORT).show();
                    }

                    doVibrator(true);
                    break;
                case R.id.btn_cread:
                    //读数据
                    Log.e("", "读数据");
//				getPermissions();
                    if (mBluetoothLeService == null) {
                        Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    mBluetoothLeService.readData(suuid, cuuid);
                    doVibrator(true);
                    break;
                default:
                    break;
            }
        }
    };
    private OnCheckedChangeListener myOnCheckedChangeListener = new OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            // TODO Auto-generated method stub
            isRrefresh = isChecked;
            Log.e("", "isChecked = " + isChecked);
        }
    };

    class WriteRunnable implements Runnable {
        private byte[] data;
        private int totalPage = 0;
        private int thisPage = 0;

        @Override
        public void run() {
            // TODO Auto-generated method stub
            byte[] flay = new byte[20];
            for (int i = 0; i < data.length; i++) {

            }
            mBluetoothLeService.writeCharacteristic(suuid, cuuid, data);
            thisPage++;
        }

    }

    private WriteRunnable myWriteRunnable = new WriteRunnable();


    public void doVibrator(boolean flay) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (!vibrator.hasVibrator()) {
            return;
        }

        if (!flay) {
            vibrator.cancel();
        } else {
            long[] pattern = new long[]{10, 200};
            vibrator.vibrate(pattern, -1);
        }
    }

    public void upData() {
        if (isRrefresh) {
            et_readdata.setText("");
            et_readdata_hx.setText("");
        }
        if (data != -1) {
            String s = "" + et_readdata.getText().toString();
//			et_readdata.setText(et_readdata.getText().toString()+" "+data);
            for (int i = 0; i < data1.length; i++) {
                s = s + " 0x" + Integer.toHexString((0xff & data1[i]));
            }
            et_readdata.setText(s);
        }
        if (data1 == null || data1.length == 0) {
            return;
        }

        StringBuffer buff = new StringBuffer();

        buff.append(et_readdata_hx.getText().toString());
        for (int i = 0; i < data1.length; i++) {
            int num = data1[i];
            buff.append(" 0x" + Integer.toHexString(num));
        }
        et_readdata_hx.setText(buff.toString());
    }

    @SuppressLint("NewApi")
    private void getPermissions() {
        if (mBluetoothLeService != null && mBluetoothLeService.mBluetoothGatt != null) {
            Log.e("", "---->getPermissions");
            UUID sid = UUID.fromString(suuid);
            UUID cid = UUID.fromString(cuuid);

            BluetoothGattService mService = mBluetoothLeService.mBluetoothGatt.getService(sid);
            BluetoothGattCharacteristic cli = mService.getCharacteristic(cid);
            int Permissions = cli.getPermissions();
            int Properties = cli.getProperties();
            Log.e("", "Permissions " + Permissions);
            Log.e("", "Properties " + Properties);
            Log.e("", "getWriteType " + cli.getWriteType());

//			int read = Properties&(BluetoothGattCharacteristic.);
            if ((BluetoothGattCharacteristic.PROPERTY_READ)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_READ))) {
                //Characteristic property: Characteristic is readable.
                Log.e("", "读取");
                isRead = true;
                btn_read.setClickable(true);
                btn_read.setEnabled(true);
            }

            if ((BluetoothGattCharacteristic.PROPERTY_WRITE)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  写
                isWrite = true;
                btn_write.setClickable(true);
                btn_write.setEnabled(true);
            }

            if ((BluetoothGattCharacteristic.PROPERTY_NOTIFY)
                    == (Properties & (BluetoothGattCharacteristic.PERMISSION_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  读
                isNotify = true;
                btn_notify.setClickable(true);
                btn_notify.setEnabled(true);
            }


        }

    }

}
