package com.example.blesearch;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends Activity {

    private ListView mDevices;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private ServiceConnection sc;
    private BluetoothLeService mBluetoothLeService; //蓝牙服务
    public static BluetoothAdapter mBluetoothAdapter;
    public static Resources mResources;
    public static Context context;

    private ProgressDialog progressDialog;
    ////////////////////////////////
    public final static String STR_PHOTOGRAPH = "Photograph";
    public final String STR_BROADCAST = "PhotographBroadcast";
    private int mConnectionState = STATE_DISCONNECTED;            //连接状态
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;
    private static final int SREVICE_UPDATA = 5;
    private Button btn_connect;
    private Button btn_red;
    private Button btn_green;
    private Button btn_orange;
    private Button btn_blue;
    private Button btn_purple;
    private Button btn_open;
    private Button btn_close;
    boolean isRed = true;
    public String cuuid = "";
    public String suuid = "";
    int time = 0;
    private Handler mHandler = new Handler(new android.os.Handler.Callback() {

        @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
        public boolean handleMessage(Message msg) {
            // TODO Auto-generated method stub
            switch (msg.what) {
                case 1:
                    //扫描到数据
                    updata();
                    getDevices();
                    break;
                case 2:
                    //连接成功
//                    showProgressDialog("获取服务...");
                    break;
                case 3:
                    //获取服务成功
//                    closeProgressDialog();
//				Intent intent = new Intent();
//		        intent.setClass(SearchActivity.this, ServicesActivity.class);
//		        /* 启动一个新的Activity */
//		        SearchActivity.this.startActivityForResult(intent, 1);
                    for (int i = 0; i < mBluetoothLeService.bleServices.size(); i++) {
                        BluetoothGattService mBluetoothGattService = mBluetoothLeService.bleServices.get(i);
                        if (mBluetoothGattService.getUuid().toString().equals(SearchActivity.this.getResources().getString(R.string.bluetooth_service_UUID))) {
                            Log.e("service-select", "" + mBluetoothGattService.getUuid());
                            List<BluetoothGattCharacteristic> bleServices = mBluetoothGattService.getCharacteristics();
                            for (BluetoothGattCharacteristic bleService : bleServices) {
                                if (bleService.getUuid().toString().equals(SearchActivity.this.getResources().getString(R.string.bluetooth_second_service_UUID))) {
                                    Log.e("service-select", "" + bleService.getUuid().toString());
//								Intent intent = new Intent(SearchActivity.this,ReadAndwriteActivity.class);
//								intent.putExtra("Service", ""+mBluetoothGattService.getUuid().toString());
//								intent.putExtra("Characteristic", ""+bleService.getUuid().toString());
//								SearchActivity.this.startActivity(intent);
                                    suuid = mBluetoothGattService.getUuid().toString();
                                    cuuid = bleService.getUuid().toString();
                                    Intent gattServiceIntent = new Intent(SearchActivity.this, BluetoothLeService.class);
                                    bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);
                                    timer.cancel();
                                    closeProgressDialog();

                                }
                            }
//						Intent intent = new Intent(SearchActivity.this,CharacteristicActivity.class);
//						intent.putExtra("position", i);
//						context.startActivity(intent);
                        }
                    }
                    break;
                case 6:
                    time++;
                    Log.d("time", String.valueOf(time));
                    if (time > 10) {
                        timer.cancel();
                        closeProgressDialog();
//                        Toast.makeText(context, "连接蓝牙失败,请手动连接..", Toast.LENGTH_LONG).show();
                    }
                    break;
                default:
                    break;
            }
            return false;
        }
    });
    //接收广播
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            //处理蓝牙连接
            int status = intent.getIntExtra(STR_PHOTOGRAPH, 1000);
            if (1000 != status) {
                switch (status) {
                    case 2:
                        break;
                    case SREVICE_UPDATA:
                        if (null != mBluetoothLeService) {
                        }
                        mHandler.sendEmptyMessage(1);
                        break;
                    case 6:
                        Toast.makeText(context, "连接成功！", Toast.LENGTH_LONG).show();
                        mHandler.sendEmptyMessage(2);
                        break;
                    case 7:
                        //断开连接
                        closeProgressDialog();
                        Toast.makeText(context, "连接断开", Toast.LENGTH_SHORT).show();
                        break;
                    case 8:
                        //获取服务成功
                        mHandler.sendEmptyMessage(3);
                        Toast.makeText(context, "获取服务成功", Toast.LENGTH_SHORT).show();
                        break;
                    case 9:
                        Toast.makeText(context, "Callback: Wrote GATT Descriptor successfully", Toast.LENGTH_LONG).show();
                        break;
                    case 10:
                        Toast.makeText(context, "Callback: Error writing GATT Descriptor", Toast.LENGTH_LONG).show();
                        break;
                    case 11:
                        //获取服务异常！
                        Toast.makeText(context, "获取服务异常！", Toast.LENGTH_LONG).show();
                        break;
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mResources = getResources();
        context = this;
        init();
        initBlu();
    }

    //
//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.search, menu);
//		return true;
//	}
//	@Override
//	public boolean onOptionsItemSelected(MenuItem item) {
//		// TODO Auto-generated method stub
//		switch (item.getItemId()) {
//		case R.id.action_settings:
//			Log.e("3333", "action_settingss");
//			if(mBluetoothLeService!=null){
//				mBluetoothLeService.scanLeDevice(true);
//			}
//			break;
//		default:
//			break;
//		}
//		return super.onOptionsItemSelected(item);
//	}
    //初始化
    @SuppressLint("NewApi")
    private void init() {

//        btn_connect = (Button) findViewById(R.id.btn_connect);
        btn_red = (Button) findViewById(R.id.btn_red);
        btn_green = (Button) findViewById(R.id.btn_green);
        btn_purple = (Button) findViewById(R.id.btn_purple);
        btn_orange = (Button) findViewById(R.id.btn_orange);
        btn_blue = (Button) findViewById(R.id.btn_blue);
        btn_open = (Button) findViewById(R.id.btn_open);
        btn_close = (Button) findViewById(R.id.btn_close);
        progressDialog = new ProgressDialog(context);
        mDevices = (ListView) findViewById(R.id.listView1);
        mLeDeviceListAdapter = new LeDeviceListAdapter();
        mDevices.setAdapter(mLeDeviceListAdapter);
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LED_ctr(false);
            }
        });

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LED_ctr(true);
            }
        });
        mDevices.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // TODO Auto-generated method stub
                BluetoothDevice device = mLeDeviceListAdapter.getDevice(position);
                connectBlu(device.getAddress());
            }
        });
//        btn_connect.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                connectBlu();
//            }
//        });

        btn_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBluetoothLeService == null) {
                    Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                byte[] jm = new byte[]{(byte) 0x28, (byte) 0xFF,
                        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                        (byte) 0xF0, (byte) 0x29};

                mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
            }
        });
        btn_green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBluetoothLeService == null) {
                    Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                byte[] jm = new byte[]{(byte) 0x28, (byte) 0x00,
                        (byte) 0xFF, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                        (byte) 0xF0, (byte) 0x29};

                mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
            }
        });
        btn_blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBluetoothLeService == null) {
                    Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                byte[] jm = new byte[]{(byte) 0x28, (byte) 0x00,
                        (byte) 0x00, (byte) 0xFF, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                        (byte) 0xF0, (byte) 0x29};

                mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
            }
        });
        btn_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBluetoothLeService == null) {
                    Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                byte[] jm = new byte[]{(byte) 0x28, (byte) 0xeb,
                        (byte) 0x95, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                        (byte) 0xF0, (byte) 0x29};

                mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
            }
        });
        btn_purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBluetoothLeService == null) {
                    Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                byte[] jm = new byte[]{(byte) 0x28, (byte) 0x4F,
                        (byte) 0x00, (byte) 0x2F, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                        (byte) 0xF0, (byte) 0x29};

                mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
            }
        });
//		mDevices.setOnItemClickListener(new OnItemClickListener() {
//
//			@Override
//			public void onItemClick(AdapterView<?> parent, View view,
//					int position, long id) {
//				// TODO Auto-generated method stub
//				BluetoothDevice device = mLeDeviceListAdapter.getDevice(position);
//
//			}
//		});

    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    public void initBlu() {
        //注册蓝牙监听
        registerReceiver(mReceiver, makeFilter());
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        boolean bleIsOpen = mBluetoothAdapter.isEnabled();
        if (mBluetoothAdapter == null || !bleIsOpen) {
            closeProgressDialog();
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
            Toast.makeText(context, "请打开蓝牙", Toast.LENGTH_LONG).show();
            return;
        }
        sc = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                // TODO Auto-generated method stub
                mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
                getPermissions();
                Log.e("3333", "scan");
                if (mBluetoothLeService != null) {
                    mBluetoothLeService.scanLeDevice(true);
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                // TODO Auto-generated method stub

            }
        };
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(STR_BROADCAST);   //为BroadcastReceiver指定action，使之用于接收同action的广播
        registerReceiver(mGattUpdateReceiver, intentFilter);
    }

    private void LED_ctr(boolean isOpen) {
        byte[] jm;
        if (isOpen) {
            jm = new byte[]{(byte) 0xFB, (byte) 0x0f, (byte) 0xFA};
        } else {
            jm = new byte[]{(byte) 0xFB, (byte) 0xf0, (byte) 0xFA};
        }
        mBluetoothLeService.writeCharacteristic(suuid, cuuid, jm);
    }

    //更新数据
    private void updata() {

    }

    // Adapter for holding devices found through scanning.扫描列表适配器
    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothDevice> mLeDevices;
        private LayoutInflater mInflator;

        public LeDeviceListAdapter() {
            super();
            mLeDevices = new ArrayList<BluetoothDevice>();
            mInflator = SearchActivity.this.getLayoutInflater();
        }

        public void addDevice(BluetoothDevice device) {
            if (!mLeDevices.contains(device)) {
                mLeDevices.add(device);
            }
        }

        public BluetoothDevice getDevice(int position) {
            return mLeDevices.get(position);
        }

        public void clear() {
            mLeDevices.clear();
        }

        @Override
        public int getCount() {
            return mLeDevices.size();
        }

        @Override
        public Object getItem(int i) {
            return mLeDevices.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                view = mInflator.inflate(R.layout.listitem_device, null);
                viewHolder = new ViewHolder();
                viewHolder.deviceAddress = (TextView) view.findViewById(R.id.device_address);
                viewHolder.deviceName = (TextView) view.findViewById(R.id.device_name);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            BluetoothDevice device = mLeDevices.get(i);
            final String deviceName = device.getName();
            if (deviceName != null && deviceName.length() > 0)
                viewHolder.deviceName.setText(deviceName);
            else
                viewHolder.deviceName.setText(device.getName());
            viewHolder.deviceAddress.setText(device.getAddress());

//            if (BluetoothLeService.scanDatas.containsKey(device.getAddress())) {
//                byte[] data = BluetoothLeService.scanDatas.get(device.getAddress());
//                String sData = "Hex:";
//                if (data.length > 20 && data[0] == 2 && data[7] > 0 && data[7] < data.length) {
//                    int n = 0xff & data[7];
////            		Log.e("", "len = "+n);
//                    for (int j = 7; j < 8 + n; j++) {
////                		String cache = String.format("%x", (0xff&data[j]));
//                        String cache = Integer.toHexString((0xff & data[j]));
//                        sData = sData + " " + cache;
//                    }
//                    viewHolder.tv_scanning_data.setText("" + sData + " - length=" + n);
//                }

//                String sScanRecord = "ScanRecord Hex:";
//                for (int j = 0; j < data.length; j++) {
////            		String cache = String.format("%x", (0xff&data[j]));
//                    String cache = Integer.toHexString((0xff & data[j]));
//                    sScanRecord = sScanRecord + " " + cache;
//                }
//                viewHolder.tv_scanRecord.setText("" + sScanRecord);
//            	scanRecord

//            }

            return view;
        }
    }

    static class ViewHolder {
        TextView deviceName;
        TextView deviceAddress;

        TextView tv_scanning_data;
        TextView tv_scanRecord;
    }

    public void getDevices() {
        mLeDeviceListAdapter.clear();
        Log.e("11", "getDevices()");
        Hashtable<String, BluetoothDevice> mDevices = mBluetoothLeService.getBluetoothDevice();
        if (null != mDevices) {
            Iterator iter = mDevices.keySet().iterator();
            while (iter.hasNext()) {
                BluetoothDevice mBluetoothDevice = mDevices.get(iter.next());
                mLeDeviceListAdapter.addDevice(mBluetoothDevice);
                mLeDeviceListAdapter.notifyDataSetChanged();
                connectBlu(mBluetoothDevice.getAddress());
                return;
            }
        }
    }

    public void showProgressDialog(String msg) {
        if (null == progressDialog) {
            return;
        }
        progressDialog = ProgressDialog.show(this, msg, "请等待...", true, false);
    }

    public void closeProgressDialog() {
        if (null == progressDialog) {
            return;
        }
        progressDialog.dismiss();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //注销蓝牙监听
        unregisterReceiver(mReceiver);
        unregisterReceiver(mGattUpdateReceiver);
    }

    @SuppressLint("NewApi")
    private void getPermissions() {
        if (mBluetoothLeService != null && mBluetoothLeService.mBluetoothGatt != null) {
            Log.e("", "---->getPermissions");
            UUID sid = UUID.fromString(suuid);
            UUID cid = UUID.fromString(cuuid);

            BluetoothGattService mService = mBluetoothLeService.mBluetoothGatt.getService(sid);
            BluetoothGattCharacteristic cli = mService.getCharacteristic(cid);
            int Permissions = cli.getPermissions();
            int Properties = cli.getProperties();
            Log.e("", "Permissions " + Permissions);
            Log.e("", "Properties " + Properties);
            Log.e("", "getWriteType " + cli.getWriteType());

//			int read = Properties&(BluetoothGattCharacteristic.);
            if ((BluetoothGattCharacteristic.PROPERTY_READ)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_READ))) {
                //Characteristic property: Characteristic is readable.
                Log.e("", "读取");
            }

            if ((BluetoothGattCharacteristic.PROPERTY_WRITE)
                    == (Properties & (BluetoothGattCharacteristic.PROPERTY_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  写
            }

            if ((BluetoothGattCharacteristic.PROPERTY_NOTIFY)
                    == (Properties & (BluetoothGattCharacteristic.PERMISSION_WRITE))) {
                //Characteristic permission: Allow encrypted read operations  读
            }


        }

    }


    private IntentFilter makeFilter() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        return filter;
    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case BluetoothAdapter.ACTION_STATE_CHANGED:
                    int blueState = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
                    switch (blueState) {
                        case BluetoothAdapter.STATE_TURNING_ON:
                            Log.e("TAG", "TURNING_ON");
                            break;
                        case BluetoothAdapter.STATE_ON:
                            Log.e("TAG", "STATE_ON");
                            initBlu();
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            Log.e("TAG", "STATE_TURNING_OFF");
                            break;
                        case BluetoothAdapter.STATE_OFF:
                            Log.e("TAG", "STATE_OFF");
                            break;
                    }
                    break;
            }
        }
    };

    Timer timer;

    public void connectBlu(String addr) {
        if (null != mBluetoothLeService) {
            mBluetoothLeService.scanLeDevice(false);
            closeProgressDialog();
            showProgressDialog("正在连接蓝牙...");
            timer = new Timer();
            time = 0;
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    mHandler.sendEmptyMessage(6);
                }
            }, 0, 1000);
            mBluetoothLeService.connectGatt(addr);
        }
    }
}
