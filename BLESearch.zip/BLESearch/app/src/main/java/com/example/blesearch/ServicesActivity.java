package com.example.blesearch;

import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ServicesActivity extends Activity{
	private ListView servicesList;
	private LeDeviceListAdapter mLeDeviceListAdapter;
	
    private ServiceConnection sc;
    private BluetoothLeService mBluetoothLeService; //蓝牙服务
	public static BluetoothAdapter mBluetoothAdapter;
	public static Resources mResources;
	public static Context context;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.service_activity);
		mResources= getResources();
		context = this;
		servicesList = (ListView) findViewById(R.id.services_list);
		mLeDeviceListAdapter = new LeDeviceListAdapter();
		servicesList.setAdapter(mLeDeviceListAdapter);
		servicesList.setOnItemClickListener(new OnItemClickListener() {

			@SuppressLint("NewApi")
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				BluetoothGattService mBluetoothGattService= mBluetoothLeService.bleServices.get(position);
				String uuid = mBluetoothGattService.getUuid().toString();
				Log.e("----", ""+uuid);
				Intent intent = new Intent(ServicesActivity.this,CharacteristicActivity.class);
				intent.putExtra("position", position);
				context.startActivity(intent);
				mBluetoothGattService.getCharacteristics();
			}
		});
		init();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK &&mBluetoothLeService!=null){
			mBluetoothLeService.stopLEService();
		}
		return super.onKeyDown(keyCode, event);
	}
	
	//服务list的适配器
    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothGattService> mServices;
        private LayoutInflater mInflator;

        public LeDeviceListAdapter() {
            super();
            mServices = new ArrayList<BluetoothGattService>();
            mInflator = ServicesActivity.this.getLayoutInflater();
        }

        public void setData(ArrayList<BluetoothGattService> mServices){
        	this.mServices = mServices;
        }

        public BluetoothGattService getService(int position) {
            return mServices.get(position);
        }

        public void clear() {
        	mServices.clear();
        }

        @Override
        public int getCount() {
            return mServices.size();
        }

        @Override
        public Object getItem(int i) {
            return mServices.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("NewApi")
		@Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                view = mInflator.inflate(R.layout.service_listitem_device, null);
                viewHolder = new ViewHolder();
                viewHolder.serviceUUID = (TextView) view.findViewById(R.id.Service_uuid);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }
            BluetoothGattService service = mServices.get(i);
            String uuid = service.getUuid().toString();
//            if(uuid!=null&&uuid.length()>=9){
//            	uuid = uuid.substring(4, 8);
//            }
            final String serviceUUID = "   UUID :" +uuid;
            Log.d("uuid",serviceUUID);
            
            if (serviceUUID != null && serviceUUID.length() > 0)
                viewHolder.serviceUUID.setText(serviceUUID);
            else
                viewHolder.serviceUUID.setText(serviceUUID);
            return view;
        }
    }
    static class ViewHolder {
        TextView serviceUUID;
    }
    private void init(){
		sc = new ServiceConnection(){
			@Override
			public void onServiceConnected(ComponentName name, IBinder service) {
				// TODO Auto-generated method stub
				mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
				Log.e("onServiceConnected", "onServiceConnected");
				mLeDeviceListAdapter.setData(mBluetoothLeService.bleServices);
				mLeDeviceListAdapter.notifyDataSetChanged();
			}
			@Override
			public void onServiceDisconnected(ComponentName name) {
				// TODO Auto-generated method stub
				
			}
		};
		Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, sc, BIND_AUTO_CREATE);
    	
    }
}
