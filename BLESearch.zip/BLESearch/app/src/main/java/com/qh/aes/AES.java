package com.qh.aes;


import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES {
	
	public static final String CIPHER_ALGORITHM_CBC = "AES/CBC/PKCS5Padding";  
  
	public static final String CIPHER_ALGORITHM_CBC_NoPadding = "AES/CBC/NoPadding"; 
	
	
	public static SecretKey secretKey;
	public static Cipher cipher; 
	
	public static final String KEY_ALGORITHM = "AES";  
	public static final String CIPHER_ALGORITHM_ECB = "AES/ECB/PKCS5Padding"; 
	
	public final static byte[] password ={	
		(byte) 0xd0,(byte) 0xf9,(byte) 0xf4,(byte) 0x8c,
		(byte) 0x59,(byte) 0xa2,(byte) 0x11,(byte) 0x1d,
		(byte) 0x33,(byte) 0x44,(byte) 0xcc,(byte) 0xda,
		(byte) 0x80,(byte) 0x84,(byte) 0x43,(byte) 0x93};  
	
	public final static byte [] content = {	(byte) 0x00,(byte) 0x05,(byte) 0x0a,(byte) 0x0f,
				(byte) 0x11,(byte) 0x16,(byte) 0x1a,(byte) 0x1f,
				(byte) 0x88,(byte) 0x99,(byte) 0xa1,(byte) 0xaa,
					(byte) 0xf1,(byte) 0xff,(byte) 0xf5,(byte) 0xf0}; 
	
 
	public static byte[] encrypt(byte[] content, byte[] password) {  
	        try {             
	            cipher = Cipher.getInstance(CIPHER_ALGORITHM_CBC_NoPadding);  
	            //KeyGenerator 生成aes算法密钥  
	            secretKey = KeyGenerator.getInstance(KEY_ALGORITHM).generateKey();  
	            
	            
	            KeyGenerator kgen = KeyGenerator.getInstance("AES");  
                kgen.init(128, new SecureRandom(password));  
                SecretKey secretKey = kgen.generateKey();  
	            
	            System.out.println("密钥的长度为：" + secretKey.getEncoded().length);  
	              
	            cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(password));//使用加密模式初始化 密钥  
	            byte[] encrypt = cipher.doFinal(content, 0, content.length); //按单部分操作加密或解密数据，或者结束一个多部分操作。  
	            String sencrypt = "";
	            for (int i = 0; i < encrypt.length; i++) {
	            	sencrypt = sencrypt+" "+Integer.toHexString((0xff&encrypt[i]));
	    		}
	            System.out.println("method4-加密：" + sencrypt);  
	            return encrypt; 
	        } catch (NoSuchAlgorithmException e) {  
	                e.printStackTrace();  
	        } catch (NoSuchPaddingException e) {  
	                e.printStackTrace();  
	        } catch (InvalidKeyException e) {  
	                e.printStackTrace();  
//	        } catch (UnsupportedEncodingException e) {  
//	                e.printStackTrace();  
	        } catch (IllegalBlockSizeException e) {  
	                e.printStackTrace();  
	        } catch (BadPaddingException e) {  
	                e.printStackTrace();  
	        } catch (InvalidAlgorithmParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	        return null;  
	}
	

	public static byte[] decrypt(byte[] content, byte[] password) {  
	        try {  
	            KeyGenerator kgen = KeyGenerator.getInstance("AES");  
                kgen.init(128, new SecureRandom(password));  
                SecretKey secretKey = kgen.generateKey(); 
	        	
	            cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(password));//使用解密模式初始化 密钥  
	            byte[] decrypt = cipher.doFinal(content);  
	            
	            String sdecrypt = "";
	            for (int i = 0; i < decrypt.length; i++) {
	            	sdecrypt = sdecrypt+" "+Integer.toHexString((0xff&decrypt[i]));
	    		}
	            System.out.println(""+sdecrypt);
	            return decrypt; 
	        } catch (InvalidKeyException e) {  
	                e.printStackTrace();  
	        } catch (IllegalBlockSizeException e) {  
	                e.printStackTrace();  
	        } catch (BadPaddingException e) {  
	                e.printStackTrace();  
	        } catch (InvalidAlgorithmParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	        return null;  
	}  
	
	public static void main(String[] args) {
		
		try {
			method4("ABCGD");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		String content = "123456789";  
//		d0 f9 f4 8c 
//		59 a2 69 1d 
//		18 53 cb da 
//		80 84 43 93 
		
//		byte [] content = {	(byte) 0x00,(byte) 0x05,(byte) 0x0a,(byte) 0x0f,
//							(byte) 0x11,(byte) 0x16,(byte) 0x1a,(byte) 0x1f,
//							(byte) 0x88,(byte) 0x99,(byte) 0xa1,(byte) 0xaa,
//							(byte) 0xf1,(byte) 0xff,(byte) 0xf5,(byte) 0xf0}; 
		
//		byte [] content = {	(byte) 0x00,(byte) 0x01,(byte) 0x02,(byte) 0x03,
//		(byte) 0x04,(byte) 0x05,(byte) 0x06,(byte) 0x07,
//		(byte) 0x08,(byte) 0x09,(byte) 0x0a,(byte) 0x0b,
//		(byte) 0x0c,(byte) 0x0d,(byte) 0x0e,(byte) 0x0f}; 
//		
//		
//
//		System.out.println("" + content);  
//		byte[] encryptResult = encrypt(content, password);  
//		
//		String data = "";
//		String strResult = "";
//		for (int i = 0; i < encryptResult.length; i++) {
//			data = data+" "+Integer.toHexString((0xff&encryptResult[i]));
//		}
//		System.out.println(""+data);
//		
//		byte[] decryptResult = decrypt(encryptResult,password);  
//		
//		for (int i = 0; i < decryptResult.length; i++) {
//			strResult = strResult+" "+Integer.toHexString((0xff&decryptResult[i]));
//		}
//		System.out.println(""+strResult);
		
		

		
//		try {
//			System.out.println(""+new String(decryptResult,"utf-8"));
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
	}
	

	static void method4(String str) throws Exception {  

		byte [] content = {	(byte) 0x00,(byte) 0x05,(byte) 0x0a,(byte) 0x0f,
		(byte) 0x11,(byte) 0x16,(byte) 0x1a,(byte) 0x1f,
		(byte) 0x88,(byte) 0x99,(byte) 0xa1,(byte) 0xaa,
		(byte) 0xf1,(byte) 0xff,(byte) 0xf5,(byte) 0xf0}; 
		

		byte [] encrypt =  encrypt(content,password);
		
		byte [] decrypt = decrypt(encrypt,password);
		
		
		byte [] encrypt1 =  encrypt(content,password);
		
		byte [] decrypt1 = decrypt(encrypt,password);
		
		
        
        System.out.println("sencrypt len：" + encrypt.length ); 
//        System.out.println("method4-加密：" + sencrypt );  
//          
//        System.out.println("method4-解密后：" + sdecrypt);  
          
    } 

}
