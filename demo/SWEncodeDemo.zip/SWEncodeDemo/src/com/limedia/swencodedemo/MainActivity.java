package com.limedia.swencodedemo;

import java.io.File;

import com.thundersoft.swencodesdk.CameraPreview;
import com.thundersoft.swencodesdk.PicToYuv;
import com.thundersoft.swencodesdk.SoftEncoder;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends Activity implements OnClickListener{
	
	private static String TAG = MainActivity.class.getSimpleName();
	private Button start,stop,switchCamera;
	private FrameLayout frameLayout;
	private Bitmap btp;
	private SoftEncoder softEncode = null;
	private Camera mCamera = null;
	private CameraPreview preview = null;
	private Bitmap resizeBmp = null;
	private int i = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//获取控件
		this.start = (Button) findViewById(R.id.start);
		this.stop = (Button) findViewById(R.id.stop);
		this.switchCamera = (Button) findViewById(R.id.camera_switch);
		this.start.setOnClickListener(this);
		this.stop.setOnClickListener(this);
		this.switchCamera.setOnClickListener(this);
		this.frameLayout = (FrameLayout) findViewById(R.id.surface);
		//生成softEncode实例
		softEncode = SoftEncoder.getInstance(this);
		
		//将一张水印图片转为test.yuv
		PicToYuv yuv = new PicToYuv();
		String path = Environment.getExternalStorageDirectory().getPath();
		//需要放一张图片手机sd卡目录（具体放哪儿可自定义）
		byte[]  fileByte = yuv.imageToByteArray("/mnt/sdcard/8.png");
		Log.e(TAG, ""+path+File.separator+"8.png");
		btp = BitmapFactory.decodeByteArray(fileByte, 0, fileByte.length);
		//水印图片缩放（参数：视频分辨率宽、高、水印图片缩放前分辨率宽、高、缩放前水印Bitmap、缩放比例宽、高）
		resizeBmp = yuv.scaleBitmap(640, 480, btp.getWidth(), btp.getHeight(), btp, 0.1f, 1f);
//		byte[] b = yuv.getYUV420sp(btp.getWidth(),btp.getHeight(),btp);
		byte[] b = yuv.getYUV420sp(resizeBmp);
		yuv.getFile(b);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.start:
			frameLayout.removeAllViews();
			preview = null;
			mCamera = null;
			//第一步init参数（视频分辨率的宽、高、是否添加水印、水印宽、高、水印起始坐标X、Y(0-100百分比)）
			softEncode.init(640, 480, true, resizeBmp.getWidth(),resizeBmp.getHeight(), 10, 10);
			//设置音频比特率（默认16000）
			softEncode.setAudioBitRate(30000);
			//设置音频采样率（默认16000），可选参数（96000、88200、64000、48000
            //	、44100、32000、24000、22050、16000、12000、11025、8000、7350）
			softEncode.setAudioSampleRate(64000);
			// 摄像头切换，0表示后置，1表示前置
			switchCamera(1, 640, 480, 25);
			//放弃了之前setSurfaceView,改成CameraPreview为一个SurfaceView
			if(preview == null ){
				preview = new CameraPreview(getApplicationContext(), mCamera, softEncode);
			}
			//将CameraPreview添加到FrameLayout中
			frameLayout.addView(preview);
			if (!softEncode.isStarted()) {
			//record参数分别为（视频分辨率宽、高、帧率、码率（1M）、视频存储路径）
			softEncode.Record(640, 480, 25,1000,"/mnt/sdcard/out.mp4");
			softEncode.startAudioRecord();
		}

			break;
		case R.id.stop:
			if (softEncode.isStarted()) {
				softEncode.stopRecord();
				softEncode.stopAudioRecord();
				frameLayout.removeAllViews();
				preview = null;
				mCamera = null;
			}
			break;
		case R.id.camera_switch:
			i++;
			if(i%2 == 0){
				frameLayout.removeAllViews();
				preview = null;
				mCamera = null;
				switchCamera(1, 640, 480, 25);
				if(preview == null ){
					preview = new CameraPreview(getApplicationContext(), mCamera, softEncode);
				}
				frameLayout.addView(preview);
			}else{
				frameLayout.removeAllViews();
				preview = null;
				mCamera = null;
				switchCamera(0, 640, 480, 25);
				if(preview == null ){
					preview = new CameraPreview(getApplicationContext(), mCamera, softEncode);
				}
				frameLayout.addView(preview);
			}
			break;
		default:
			break;
		}
	}
	
	public void setCameraParameters(int width,int height,int frameRate){
		if(mCamera != null ){
			Log.e(TAG, "setCameraParameters");
			Camera.Parameters params = mCamera.getParameters();
			params.setPreviewSize(width, height);
			params.setPreviewFrameRate(frameRate);
			mCamera.setParameters(params);
		}else{
			Log.d(TAG, "camera is null !!");
		}
	}
	
	public void switchCamera(int cameraPos, int width, int height, int frameRate){
		CameraInfo cameraInfo = new CameraInfo();
		int cameraCount = Camera.getNumberOfCameras();// 得到摄像头的个数
		Log.v(TAG, "camera number is : "+cameraCount+"");
		for (int i = 0; i < cameraCount; i++) {
			Camera.getCameraInfo(i, cameraInfo);
			if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT && cameraPos == 1){
				releaseCamera();
				openCamera(cameraPos);
				setCameraParameters(width, height, frameRate);
			}else if(cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK && cameraPos == 0){
				releaseCamera();
				openCamera(cameraPos);
				setCameraParameters(width, height, frameRate);
			}
			}
	}
	
	public void openCamera(int i){
		if(mCamera == null){
			Log.e(TAG, "openCamera");
			mCamera = getCameraInstance(i);
			Log.e(TAG,"get camera:"+mCamera==null?"fail":"success" );
		}else{
			Log.e(TAG, "mCamera == null");
		}
	}
	
	public static Camera getCameraInstance(int i) {
		Camera c = null;
		try {
			c = Camera.open(i); // attempt to get a Camera instance
		} catch (Exception e) {
			// Camera is not available (in use or does not exist)
			Log.e(TAG, "get mCamera fail:"+e.getMessage());
		}
		return c; // returns null if camera is unavailable
	}
	
	public void releaseCamera() {
		if (mCamera != null) {
			mCamera.setPreviewCallback(null) ;
			mCamera.stopPreview();
			mCamera.release(); // release the camera for other applications
			mCamera = null;
		}
	}
}
