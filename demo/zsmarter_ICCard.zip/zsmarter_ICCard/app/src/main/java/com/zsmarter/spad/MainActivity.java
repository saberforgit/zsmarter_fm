package com.zsmarter.spad;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.zsmarter.spad.nfc.CardReaderActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn_spad_nfc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        initListener();
    }

    private void initView() {
        btn_spad_nfc = (Button) findViewById(R.id.btn_spad_nfc);
    }

    private void initData() {

    }

    private void initListener() {
        btn_spad_nfc.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_spad_nfc:
                jumpTo(CardReaderActivity.class);
                break;
        }
    }

    private void jumpTo(Class clazz) {
        startActivity(new Intent(this,clazz));
    }
}
