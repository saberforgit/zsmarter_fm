package com.zsmarter.spad.nfc;

import android.app.Activity;
import android.content.IntentFilter;
import android.nfc.TagLostException;
import android.nfc.tech.IsoDep;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.NfcA;
import android.nfc.tech.NfcB;
import android.nfc.tech.NfcF;
import android.nfc.tech.NfcV;
import android.util.Log;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Created by wangxf on 2016/9/22.
 */

public class CardManger {

    public static String[][] mTechLists;
    public static IntentFilter[] intentFiltersArray;

    static {
        try {
            mTechLists = new String[][]{{NfcF.class.getName()}, {NfcA.class.getName()}, {NfcB.class.getName()}, {NfcV.class.getName()}, {IsoDep.class.getName()}, {MifareClassic.class.getName()}};
            IntentFilter var0 = new IntentFilter("android.nfc.action.NDEF_DISCOVERED");
            IntentFilter var1 = new IntentFilter("android.nfc.action.TECH_DISCOVERED", "*/*");
            IntentFilter var2 = new IntentFilter("android.nfc.action.TAG_DISCOVERED");
            intentFiltersArray = new IntentFilter[]{var0, var1, var2};
        } catch (IntentFilter.MalformedMimeTypeException var3) {
            var3.printStackTrace();
        }
    }
    /**
     * 初始化ic读卡器
     */
    protected static void initICReader(IsoDep isoDep) {

        try {
            //初始化读卡数据
            setAid(isoDep.transceive(InQuireCommand.PPSE), InQuireCommand.SelApp);
            //查询卡信息
            isoDep.transceive(InQuireCommand.SelApp);
        } catch (TagLostException e) {
            Log.w(TagLostException.class.getName(), e.getMessage());
//            initICReader(isoDep);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 配置读卡方式
     *
     * @param isoDep
     * @param
     * @return
     */
    protected static String readICCardNumExc(IsoDep isoDep, byte[] ICInitCMD, byte[] ICReadCMD) {
        String icCardNum = null;
        try {
            isoDep.transceive(ICInitCMD);
            byte[] cardInfoByte = isoDep.transceive(ICReadCMD);
            icCardNum = CardUtils.hexToString(cardInfoByte);
        } catch (TagLostException e) {
            Log.w(TagLostException.class.getName(), e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return icCardNum;
    }

    /**
     * 读取卡号
     *
     * @return
     */
    protected static String readICCardNum(Activity mContext, IsoDep isoDep, byte[] ICNumInQuireCommand) {
        String icCardNum = null;
        try {
            //查询卡号
            byte[] cardNumByteFinal;
            byte[] cardNumByte = new byte[0];
            cardNumByte = isoDep.transceive(ICNumInQuireCommand);
            if ((cardNumByte.length > 0) && ((cardNumByte[1] & 0xFF) > 0) && (cardNumByte[2] == 87) && (cardNumByte[3] == 19)) {
                cardNumByteFinal = new byte[10];
                System.arraycopy(cardNumByte, 4, cardNumByteFinal, 0, cardNumByteFinal.length);
                icCardNum = CardUtils.bytesToHexString(cardNumByteFinal);
                int i = (icCardNum).toUpperCase().indexOf("D");
                if (i > 0) {
                    icCardNum = (icCardNum).substring(0, i);
                }
            } else {
                Log.d("icCardNum", "卡号读取失败");
            }
        } catch (TagLostException e) {
            Log.w(TagLostException.class.getName(), e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return icCardNum;
    }


    /**
     * 查询ic卡余额
     */
    protected static String readICBalance(IsoDep isoDep, byte[] ICBalaneInQuireCommand) {
        String cardBalanceString = null;
        try {
            byte[] cardBalanceByteFinal;
            byte[] cardBalanceByte = new byte[0];
            cardBalanceByte = isoDep.transceive(ICBalaneInQuireCommand);
            if ((cardBalanceByte.length > 9) && ((cardBalanceByte[0] & 0xFF) == 159)) {
                cardBalanceByteFinal = new byte[cardBalanceByte[2] & 0xFF];
                System.arraycopy(cardBalanceByte, 3, cardBalanceByteFinal, 0, cardBalanceByteFinal.length);
                cardBalanceString = show12yue(CardUtils.bytesToHexString(cardBalanceByteFinal));
            } else {
                Log.d("cardBalance", "没查到余额");
            }
        } catch (TagLostException e) {
            Log.w(TagLostException.class.getName(), e.getMessage());
//            readICBalance(isoDep,ICBalaneInQuireCommand);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cardBalanceString;
    }

    protected static String readICCardHostory(IsoDep isoDep, byte[] ICBalaneInQuireCommand) {
        StringBuffer chaxunJILU = new StringBuffer();

        try {
            byte[] localObject = isoDep.transceive(ICBalaneInQuireCommand);
            byte[] localObject3 = new byte[6];
            byte[] localObject1 = new byte[6];
            System.arraycopy(localObject, 0, localObject3, 0, 6);
            System.arraycopy(localObject, 6, localObject1, 0, 6);
            String jlInfo = CardUtils.bytesToHexString(localObject3);
            String jl1 = show12yueJILU(CardUtils.bytesToHexString(localObject1));
            chaxunJILU.append("\n上次交易记录:\n交易时间:" + (jlInfo));
            chaxunJILU.append("\n交易金额:" + jl1);
        } catch (TagLostException e) {
            Log.w(TagLostException.class.getName(), e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return chaxunJILU.toString();
    }

    public static String show12yueJILU(String paramString) {
        if (paramString.length() >= 12) {
            paramString = moneyFormat(new BigDecimal(paramString).divide(new BigDecimal("100")).toString()) + "元";
            return "" + paramString;
        }
        return "显示失败";
    }

    /**
     * 金额格式化
     *
     * @param paramString
     * @return
     */
    private static String moneyFormat(String paramString) {
        Object localObject;
        if (paramString != null) {
            localObject = paramString;
            if (!paramString.equalsIgnoreCase("")) ;
        } else {
            localObject = "0";
        }
        try {
            DecimalFormat localObject1 = new DecimalFormat();
            localObject1.applyPattern("#,###,###,##0.00");
            return localObject1.format(localObject);
        } catch (Exception s) {
            Log.w(CardManger.class.getName(), s.getMessage());
        }
        return "0";
    }

    /**
     * 获取金额
     *
     * @param paramString
     * @return
     */
    public static String show12yue(String paramString) {
        if (paramString.length() >= 12) {
            paramString = moneyFormat(new BigDecimal(paramString).divide(new BigDecimal("100")).toString()) + "元";
            return paramString;
        }
        return "显示失败";
    }

    /**
     * 初始化卡信息
     *
     * @param paramArrayOfByte
     * @param selApp
     */
    private static void setAid(byte[] paramArrayOfByte, byte[] selApp) {
        int i = 0;
        if (((paramArrayOfByte[0] & 0xFF) == 111) && ((paramArrayOfByte[2] & 0xFF) == 132) && ((paramArrayOfByte[18] & 0xFF) == 165) && ((paramArrayOfByte[25] & 0xFF) == 79))
            i = paramArrayOfByte[26];
        try {
            byte[] arrayOfByte1 = new byte[i];
            System.arraycopy(paramArrayOfByte, 27, arrayOfByte1, 0, i);
            paramArrayOfByte = new byte[4];
            paramArrayOfByte[1] = -92;
            paramArrayOfByte[2] = 4;
            byte[] arrayOfByte2 = new byte[paramArrayOfByte.length + i + 1];
            System.arraycopy(paramArrayOfByte, 0, arrayOfByte2, 0, paramArrayOfByte.length);
            arrayOfByte2[4] = ((byte) i);
            System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 5, arrayOfByte1.length);
            selApp = arrayOfByte2;
            return;
        } catch (Exception s) {
        }
    }
}
