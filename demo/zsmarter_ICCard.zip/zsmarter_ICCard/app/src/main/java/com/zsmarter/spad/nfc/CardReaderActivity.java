package com.zsmarter.spad.nfc;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.zsmarter.spad.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CardReaderActivity extends Activity implements View.OnClickListener {

    private NfcAdapter nfcAdapter;
    private PendingIntent mPendingIntent;
    private boolean isFirsRun = true;
    private boolean isProcessIntent;
    public Tag tag;
    private Activity mContext;
    Button btn_readCard;
    Button btn_closeCard;


    public void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setForground();
    }


    @Override
    public void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            disableNdefExchangeMode();
        }
        isProcessIntent = true;

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc);
        btn_readCard = (Button) findViewById(R.id.btn_readcard);
        btn_closeCard = (Button) findViewById(R.id.btn_closeCard);
        btn_readCard.setOnClickListener(this);
        btn_closeCard.setOnClickListener(this);
    }

    public void startCardReader(final Activity moduleContext) {
        LogUtils.d("startCardReader...");
        this.mContext = moduleContext;
        try {
            if (!initData()) {
                sendMessage(ConsantHelper.NFC_CLOSE, "initIDModule erro", cardHandler);
                return;
            }
            ;
            setForground();
        } catch (Exception e) {
            sendMessage(ConsantHelper.NFC_START_ERR, e.getMessage(), cardHandler);
        }
    }

    public void closeCardReader(final Activity moduleContext) {
        LogUtils.d("closeCardReader...");
        this.mContext = moduleContext;
        if (nfcAdapter != null) {
            disableNdefExchangeMode();
            LogUtils.d("关闭读卡器");
        }
        nfcAdapter = null;
    }

    private boolean initData() {
        LogUtils.d("initData...");
        if (nfcAdapter != null) {
            return true;
        }
        // 获取默认的NFC控制器
        nfcAdapter = NfcAdapter.getDefaultAdapter(mContext);
        if (nfcAdapter != null) {
            return true;
        }
        if (nfcAdapter.isEnabled()) {
            return true;
        }
        return false;
    }


    /**
     * 设定前台系统可用
     *
     * @param mPendingIntent
     */
    private void enableNdefExchangeMode(PendingIntent mPendingIntent) {
        if (nfcAdapter == null) {
            return;
        }
        nfcAdapter.enableForegroundDispatch(mContext, mPendingIntent,
                CardManger.intentFiltersArray, CardManger.mTechLists);
    }


    private void setForground() {
        // 设置优先级-前台发布系统，
        if (nfcAdapter != null) {
            LogUtils.d("设置前台优先");
            mPendingIntent = PendingIntent.getActivity(mContext, 0, mContext.getIntent(), 0);
            enableNdefExchangeMode(mPendingIntent);
            isFirsRun = false;
            enableReaderMode();
        }
    }

    @TargetApi(19)
    private void enableReaderMode() {
        Bundle options = new Bundle();
        options.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 1000);
        int READER_FLAGS = NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NFC_B | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK;
        if (nfcAdapter != null) {
            LogUtils.d("读卡器可用...");
            nfcAdapter.enableReaderMode(mContext, new MyReaderCallback(), READER_FLAGS, options);
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_readcard:
                startCardReader(this);
                break;
            case R.id.btn_closeCard:
                closeCardReader(this);
                break;
        }
    }


    @TargetApi(19)
    public class MyReaderCallback implements NfcAdapter.ReaderCallback {

        @Override
        public void onTagDiscovered(final Tag arg0) {
            mContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        tag = arg0;
                        LogUtils.d((tag.toString()));
                        LogUtils.d("开始读卡。。。");
                        String[] techList = arg0.getTechList();
                        String cardType = checkTagTypeList(techList);
                        switch (cardType) {
                            case "IC":
                                JSONObject icCardJson = new JSONObject();
                                JSONObject icCardInfo = new JSONObject();
                                IsoDep isodep = IsoDep.get(tag);
                                //  链接读卡设备
                                if (isodep == null) {
                                    icCardJson.put("code", "01");
                                    icCardJson.put("message", "not support this nfc");
                                    icCardJson.put("cardType", "IC");
                                    sendMessage(ConsantHelper.NFC_CLOSE, icCardJson.toString(), cardHandler);
                                    return;
                                }
                                isodep.connect();
                                if (techList == null || techList.length <= 0) {
                                    Toast.makeText(CardReaderActivity.this.mContext, "获取标签失败", Toast.LENGTH_LONG).show();
                                    return;
                                }
                                if (!isodep.isConnected()) {
                                    Toast.makeText(CardReaderActivity.this.mContext, "获取标签失败", Toast.LENGTH_LONG).show();
                                    return;
                                }
                                CardManger.initICReader(isodep);
                                String icCardNum = CardManger.readICCardNum(mContext, isodep, InQuireCommand.chaxunID);
                                String icCardBalance = CardManger.readICBalance(isodep, InQuireCommand.chaxunYE);
                                String icCardHos = CardManger.readICCardHostory(isodep, InQuireCommand.chaxunJILU);
                                icCardInfo.put("icCardNum", icCardNum);
                                icCardInfo.put("icCardBalance", icCardBalance);
                                icCardInfo.put("icCardHos", icCardHos);
                                icCardJson.put("icCardInfo", icCardInfo);
                                icCardJson.put("cardType", "IC");
                                Log.d("IC", icCardJson.toString());
                                sendMessage(ConsantHelper.NFC_IC_INFO, icCardJson.toString(), cardHandler);
                                break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    /**
     * 取消前台系统
     */
    private void disableNdefExchangeMode() {
        nfcAdapter.disableForegroundDispatch(mContext);
        isFirsRun = true;
        disableReaderMode();
    }

    private void disableReaderMode() {
        if (nfcAdapter != null) {
            nfcAdapter.disableReaderMode(mContext);
            nfcAdapter = null;
        }
    }


    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        disableReaderMode();
    }


    private Handler cardHandler = new Handler() {
        @SuppressLint("HandlerLeak")
        public void handleMessage(Message msg) {
            try {
                switch (msg.what) {
                    case ConsantHelper.NFC_CLOSE:
                        Toast.makeText(mContext, "nfc不支持或者未开启", Toast.LENGTH_SHORT).show();
                        break;
                    case ConsantHelper.NFC_START_ERR:
                        Toast.makeText(mContext, "开启nfc读卡器失败", Toast.LENGTH_SHORT).show();
                        break;
                    case ConsantHelper.NFC_CLOSE_ERR:
                        Toast.makeText(mContext, "关闭nfc读卡器失败", Toast.LENGTH_SHORT).show();
                        break;
                    case ConsantHelper.NFC_INITID_ERR:
                        Toast.makeText(mContext, "关闭nfc读卡器失败", Toast.LENGTH_SHORT).show();
                        break;
                    case ConsantHelper.NFC_CARD_TYPE_ERR:
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "不支持此卡片");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null,idCardJson, false);
                        Toast.makeText(mContext, "不支持此卡片", Toast.LENGTH_SHORT).show();
                        break;
                    case ConsantHelper.NFC_CARD_ERR:
                        Toast.makeText(mContext, "NFC读卡失败、请重新放卡", Toast.LENGTH_SHORT).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "NFC读卡失败、请重新放卡");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        break;
                    case ConsantHelper.NFC_CONNECT_ERR:
                        Toast.makeText(mContext, "NFC连接卡片失败、请重新放卡", Toast.LENGTH_SHORT).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "NFC连接卡片失败、请重新放卡");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        break;
                    case ConsantHelper.NET_CONNECT_SERVER_ERR:
                        Toast.makeText(mContext, "连接服务器异常、请检查网络", Toast.LENGTH_SHORT).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "连接服务器异常、请检查网络");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        break;
                    case ConsantHelper.NET_RECIVE_ERR:
                        //接收错误，再次开启读卡流程
                        Toast.makeText(mContext, "接收异常、请检查网络", Toast.LENGTH_SHORT).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "接收异常、请检查网络");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        //myHandler.sendEmptyMessage(5);
                        break;
//                    case -2:
//                        break;
//                    case -1:
//                        break;
//                    case 0:
//                        break;
//                    case 1:
//                        break;
                    case 12:
                        Toast.makeText(mContext, "NFC没有检测到卡片、请重新刷卡", Toast.LENGTH_LONG).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "NFC没有检测到卡片、请重新刷卡");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        break;
                    case 13:
                        Toast.makeText(mContext, "网络错误、请重新刷卡", Toast.LENGTH_LONG).show();
//                        idCardJson.put("code", "01");
//                        idCardJson.put("message", "网络错误、请重新刷卡");
//                        idCardJson.put("cardType", "ID");
//                        callbackContext.error(null, idCardJson, false);
                        break;

                    case ConsantHelper.NFC_IC_INFO:
                        Toast.makeText(mContext, msg.obj.toString(), Toast.LENGTH_LONG).show();
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
                // TODO: handle exception
            }

        }
    };

    private String checkTagTypeList(String[] techList) {
        String cardType = null;
        for (String tech : techList) {
            switch (tech) {
                case "android.nfc.tech.IsoDep":
                case "android.nfc.tech.NfcA":
                    cardType = "IC";
                    break;
                case "android.nfc.tech.NfcB":
                    cardType = "ID";
                    break;
            }
        }
        return cardType;
    }


    /**
     * 保存图片
     */
    public String saveImage(Bitmap bmp) {
        File appDir = new File(Environment.getExternalStorageDirectory(), "IDTest");
        if (!appDir.exists()) {
            appDir.mkdir();
        }
        String fileName = System.currentTimeMillis() + ".jpg";
        File file = new File(appDir, fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
            return file.getPath();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public void sendMessage(int type, String mssg, Handler handler) {
        Message msg = new Message();
        msg.what = type;
        msg.obj = mssg;
        handler.sendMessage(msg);
    }
}
