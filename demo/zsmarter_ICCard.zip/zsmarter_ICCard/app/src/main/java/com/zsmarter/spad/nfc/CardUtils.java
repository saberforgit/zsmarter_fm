package com.zsmarter.spad.nfc;
import java.nio.ByteBuffer;

/**
 * Created by wangxf on 2016/9/7.
 */

public class CardUtils {


    //16转byte
    public static byte[] hexStringToByte(String hex) {
        int len = (hex.length() / 2);
        byte[] result = new byte[len];
        char[] achar = hex.toCharArray();
        for (int i = 0; i < len; i++) {
            int pos = i * 2;
            result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
        }
        return result;
    }

    //char 转byte
    private static byte toByte(char c) {
        byte b = (byte) "0123456789ABCDEF".indexOf(c);
        return b;
    }


    //转换nfc的读卡命令
    private byte[] getSelectCommand(byte[] aid) {
        final ByteBuffer cmd_pse = ByteBuffer.allocate(aid.length + 6);
        cmd_pse.put((byte) 0x00) // CLA Class
                .put((byte) 0xA4) // INS Instruction
                .put((byte) 0x04) // P1 Parameter 1
                .put((byte) 0x00) // P2 Parameter 2
                .put((byte) aid.length) // Lc
                .put(aid).put((byte) 0x00); // Le
        return cmd_pse.array();
    }

    //16转字符串
    public static String hexToString(byte[] data) {
        String temp = "";
        for (byte d : data) {
            temp += String.format("%02x", d);
        }
        return temp;
    }


    //byte转16
    public static byte byteToHex(byte arg) {
        byte hex = 0;
        if (arg >= 48 && arg <= 57) {
            hex = (byte) (arg - 48);
        } else if (arg >= 65 && arg <= 70) {
            hex = (byte) (arg - 55);
        } else if (arg >= 97 && arg <= 102) {
            hex = (byte) (arg - 87);
        }
        return hex;
    }

    //string 转16
    private byte[] StringToHex(String data) {
        byte temp[] = data.getBytes();
        byte result[] = new byte[temp.length / 2];
        for (int i = 0; i < result.length; i++) {
            result[i] = (byte) (byteToHex(temp[i * 2]) << 4 | byteToHex(temp[i * 2 + 1]));
        }
        return result;
    }

    //byte转int
    private int byteToInt(byte[] b, int n) {
        int ret = 0;
        for (int i = 0; i < n; i++) {
            ret = ret << 8;
            ret |= b[i] & 0x00FF;
        }
        if (ret > 100000 || ret < -100000)
            ret -= 0x80000000;
        return ret;
    }

    public static byte[] hexStringToBytes(String var0) {
        if(var0 != null && !var0.equals("")) {
            if(var0.length() % 2 != 0) {
                var0 = var0 + "0";
            }

            int var1 = (var0 = var0.toUpperCase()).length() / 2;
            char[] var6 = var0.toCharArray();
            byte[] var2 = new byte[var1];

            for(int var3 = 0; var3 < var1; ++var3) {
                int var4 = var3 << 1;
                char var5 = var6[var4];
                int var10002 = (byte)"0123456789ABCDEF".indexOf(var5) << 4;
                var5 = var6[var4 + 1];
                var2[var3] = (byte)(var10002 | (byte)"0123456789ABCDEF".indexOf(var5));
            }

            return var2;
        } else {
            return null;
        }
    }

    public static byte[] shortToBytes(short var0) {
        byte[] var1;
        (var1 = new byte[2])[1] = (byte)var0;
        var1[0] = (byte)(var0 >> 8);
        return var1;
    }

    public static short bytesToShort(byte[] var0) {
        return (short)(var0[1] & 255 | (var0[0] & 255) << 8);
    }

    public static String bytesToHexString(byte[] var0) {
        StringBuilder var1 = new StringBuilder("");
        if(var0 != null && var0.length > 0) {
            for(int var2 = 0; var2 < var0.length; ++var2) {
                String var3;
                if((var3 = Integer.toHexString(var0[var2] & 255)).length() < 2) {
                    var1.append(0);
                }

                var1.append(var3);
            }

            return var1.toString();
        } else {
            return null;
        }
    }

    public String printHexString(byte[] var1) {
        String var2 = "";

        for(int var3 = 0; var3 < var1.length; ++var3) {
            String var4;
            if((var4 = Integer.toHexString(var1[var3] & 255)).length() == 1) {
                var4 = "0" + var4;
            }

            var2 = var2 + var4;
        }

        return var2;
    }

    public static byte[] bigtosmall(byte[] var0) {
        if(var0.length > 0) {
            byte[] var1 = new byte[var0.length];

            for(int var2 = 0; var2 < var0.length; ++var2) {
                if(var2 % 2 == 0) {
                    if(var2 + 1 < var0.length) {
                        var1[var2] = var0[var2 + 1];
                    }
                } else {
                    var1[var2] = var0[var2 - 1];
                }
            }

            return var1;
        } else {
            return null;
        }
    }

    public static byte[] intToByteArray(int var0) {
        byte[] var1 = new byte[2];

        for(int var2 = 0; var2 < 4; ++var2) {
            int var3 = 1 - var2 << 3;
            var1[var2] = (byte)(var0 >>> var3);
        }

        return var1;
    }

    public static byte[] longToByteArray(long var0) {
        byte[] var2 = new byte[2];

        for(int var3 = 0; var3 < 8; ++var3) {
            int var4 = 1 - var3 << 3;
            var2[var3] = (byte)((int)(var0 >>> var4 & 255L));
        }

        return var2;
    }

    public static byte[] int2byte(int var0) {
        byte[] var1;
        (var1 = new byte[4])[0] = (byte)var0;
        var1[1] = (byte)(var0 >> 8);
        var1[2] = (byte)(var0 >> 16);
        var1[3] = (byte)(var0 >> 24);
        return var1;
    }

    public static int byte2int(byte[] var0) {
        return var0[0] & 255 | var0[1] << 8 & '\uff00';
    }

    public static byte[] intTo2byte(int var0) {
        byte[] var1;
        (var1 = new byte[2])[1] = (byte)var0;
        var1[0] = (byte)(var0 >> 8);
        return var1;
    }

}
