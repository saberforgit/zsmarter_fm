package com.zsmarter.spad.nfc;

public class ConsantHelper {
	public static final String VERSION = "V1.0";
	public static final int READ_CARD_SUCCESS = 100;
	
	public static final int READ_CARD_second = 2;
	
	public static final int NFC_CONNECT_ERR = -25;
	public static final int NFC_CARD_TYPE_ERR = -24;
	public static final int NFC_TAG_ERR = -24;
	public static final int NFC_CARD_ERR = -23;
	
	public static final int NET_CONNECT_SERVER_ERR = -30;
	public static final int NET_SEND_ERR = -31;
	public static final int NET_RECIVE_ERR = -32;
	public static final int NFC_START_ERR = -33;
	public static final int NFC_CLOSE_ERR = -34;
	public static final int NFC_CLOSE= -35;
	public static final int NFC_INITID_ERR= -36;
	public static final int NFC_IC_INFO= 111;

	
	public static final int Progress  = 82;
	public static final int ProgressPass  = 86;
	
	
	public static final int READ_CARD_NO_READ = -1; 
	public static final int READ_CARD_BUSY = -2; // 
	public static final int READ_CARD_NET_ERR = 3;
	public static final int READ_CARD_NO_CARD = -4;

	public static final int READ_CARD_SAM_ERR = -5;
	public static final int READ_CARD_OTHER_ERR = -6; 
	public static final int READ_CARD_NEED_TRY = -7;
	public static final int READ_CARD_OPEN_FAILED = -8;
	public static final int READ_CARD_NO_CONNECT = -9;
	public static final int READ_CARD_NO_SERVER = -10;
	public static final int READ_CARD_FAILED = -11;
	public static final int READ_CARD_SN_ERR = -12;

}