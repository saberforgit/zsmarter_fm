package com.zsmarter.spad.nfc;

/**
 * Created by wangxf on 2016/9/22.
 */

public class InQuireCommand {
    public static byte[] PPSE;
    public static byte[] SelApp;
    public static byte[] chaxunID;
    public static byte[] chaxunYE;
    public static byte[] chaxunJILU ;

    static {
        byte[] arrayOfByte = new byte[19];
        arrayOfByte[1] = -92;
        arrayOfByte[2] = 4;
        arrayOfByte[4] = 14;
        arrayOfByte[5] = 50;
        arrayOfByte[6] = 80;
        arrayOfByte[7] = 65;
        arrayOfByte[8] = 89;
        arrayOfByte[9] = 46;
        arrayOfByte[10] = 83;
        arrayOfByte[11] = 89;
        arrayOfByte[12] = 83;
        arrayOfByte[13] = 46;
        arrayOfByte[14] = 68;
        arrayOfByte[15] = 68;
        arrayOfByte[16] = 70;
        arrayOfByte[17] = 48;
        arrayOfByte[18] = 49;
        PPSE = arrayOfByte;
        arrayOfByte = new byte[12];
        arrayOfByte[1] = -92;
        arrayOfByte[2] = 4;
        arrayOfByte[4] = 7;
        arrayOfByte[5] = -96;
        arrayOfByte[8] = 3;
        arrayOfByte[9] = 51;
        arrayOfByte[10] = 1;
        arrayOfByte[11] = 1;
        SelApp = arrayOfByte;
        arrayOfByte = new byte[5];
        arrayOfByte[0] = -128;
        arrayOfByte[1] = -54;
        arrayOfByte[2] = -97;
        arrayOfByte[3] = 121;
        chaxunYE = arrayOfByte;
        arrayOfByte = new byte[5];
        arrayOfByte[1] = -78;
        arrayOfByte[2] = 1;
        arrayOfByte[3] = 12;
        chaxunID = arrayOfByte;
        arrayOfByte = new byte[5];
        arrayOfByte[1] = -78;
        arrayOfByte[2] = 1;
        arrayOfByte[3] = 92;
        chaxunJILU = arrayOfByte;
    }

}
